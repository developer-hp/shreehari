<?php
/* @var $this CasheventController */
/* @var $model Cashevent */
/* @var $form CActiveForm */
?>

<?php $title="Cash";?>

<div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1><?php echo $title;?></h1>
            </div>
        </div>
        <div class="col-sm-6 hidden-xs">
            <div class="header-section">
                <ul class="breadcrumb breadcrumb-top">
                    <?php 
                     $action=Yii::app()->controller->action->id;
                      if($action!='add'):?>
                        <li><?php                    
                           echo CHtml::link($title, array('admin'));
                          ?></li>
                    <?php endif;?>
                    <li><?php echo $model->isNewRecord ? Yii::t('yii','Create') : Yii::t('yii','Edit'); ?></li>
                    <input type="hidden" class="test" value="<?php echo $model->isNewRecord ? 'Create' : 'Edit'; ?>">
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
     <!-- Horizontal Form Block -->
        <div class="block">
            
            <!-- Horizontal Form Title -->
            <div class="block-title">
                <h2><?php echo $model->isNewRecord ? Yii::t('yii','Create') : Yii::t('yii','Edit'); ?> <?php echo $title;?></h2>
            </div>

              <?php if (Yii::app()->user->hasFlash('success')): ?>
                <div class="alert alert-success alert-dismissable">
                    <p><?php echo Yii::app()->user->getFlash('success'); ?></p>
                </div>
                <?php endif; ?> 

					<?php $form=$this->beginWidget('CActiveForm', array(
						'id'=>'cashevent-form',
						'enableAjaxValidation' => true,
						    'htmlOptions' => array('class' => 'form-horizontal form-bordered', 'enctype' => 'multipart/form-data'),
						    'clientOptions' => array(
						        'validateOnSubmit' => true,
						    ),
						    'errorMessageCssClass' => 'help-block animation-slideUp form-error',
						// Please note: When you enable ajax validation, make sure the corresponding
						// controller action is handling ajax validation correctly.
						// There is a call to performAjaxValidation() commented in generated controller code.
						// See class documentation of CActiveForm for details on this.
						// 'enableAjaxValidation'=>false,
					)); ?>

						<!-- <p class="note">Fields with <span class="required">*</span> are required.</p> -->

						<?php // echo $form->errorSummary($model); ?>


						<div class="form-group">
							<?php echo $form->labelEx($model,'customer_id', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-6">
							<?php // echo $form->textField($model,'customer_id', array('class' => 'form-control')); 
								// $customer = Customer::model()->findAll();
								// print_r($customer);
								echo $form->dropDownList($model,'customer_id',CHtml::listData(Customer::model()->findAll(array("condition"=>"is_deleted = 0")),'id','name'),
									array(
										'prompt'=>'Select',
										'class'=>'form-control select-select2',
									)); 
							?>
							<?php echo $form->error($model,'customer_id'); ?>
							</div>
						</div>

						<div class="form-group">
							<?php echo $form->labelEx($model,'cash_type', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-3">
							<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
							$cash_type=array(1=>'IN',2=>'OUT');
							echo $form->dropDownList($model,'cash_type',$cash_type,
											array(
												'prompt'=>'Select',
												'class'=>'form-control',
											)); 
							?>
							<?php echo $form->error($model,'cash_type'); ?>
							</div>
						</div>

						<div class="form-group">
							<?php echo $form->labelEx($model,'amount', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-3">
							<?php echo $form->textField($model,'amount', array('class' => 'form-control','maxlength'=>13)); ?>
							<?php echo $form->error($model,'amount'); ?>
							</div>
						</div>

						<div class="form-group">
							<?php echo $form->labelEx($model,'gold_type', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-3">
							<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
							$gold_type=array(1=>'IN',2=>'OUT');
							echo $form->dropDownList($model,'gold_type',$gold_type,
								array(
									'prompt'=>'Select',
									'class'=>'form-control gold_type',
								)); 
							?>
							<?php echo $form->error($model,'gold_type'); ?>
							</div>
						</div>

						<div class="form-group">
							<?php echo $form->labelEx($model,'gold_amount', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-3">
							<?php echo $form->textField($model,'gold_amount', array('class' => 'form-control set_amount','maxlength'=>13)); ?>
							<?php echo $form->error($model,'gold_amount'); ?>
							</div>
						</div>

					<div class="form-group form-actions">
				        <div class="col-md-9 col-md-offset-3">
				            <?php echo CHtml::submitButton($model->isNewRecord ? Yii::t('yii','Save') : Yii::t('yii','Save'), array('class' => 'btn btn-effect-ripple btn-primary submit')); ?>
				            <?php echo CHtml::link(Yii::t('yii','Cancel'), array('admin'), array('class' => 'btn btn-effect-ripple btn-danger')) ?>
				        </div>
				    </div>
				<?php $this->endWidget(); ?>
			</div>
	</div>
</div>



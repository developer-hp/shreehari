

<?php $title="Cash Detail";?>
<div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1><?php echo $title;?></h1>
            </div>
        </div>
        <div class="col-sm-6 hidden-xs">
            <div class="header-section">
                <ul class="breadcrumb breadcrumb-top">
                    <li><?php echo CHtml::link($title, array('admin')) ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <!-- Partial Responsive Block -->
        <div class="block">
            <!-- Partial Responsive Title -->
            <div class="block-title">
                <h2><?php echo $title;?></h2>	                     
            </div>

            <!-- END Partial Responsive Title -->
            <?php if (Yii::app()->user->hasFlash('success')): ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><strong>Success</strong></h4>
                    <p><?php echo Yii::app()->user->getFlash('success'); ?></p>
                </div>
            <?php endif; ?>

				<?php $this->widget('zii.widgets.CDetailView', array(
					'data'=>$model,
					'htmlOptions'=>array('class'=>'table table-striped'),
					'attributes'=>array(
						// 'id',
						// 'user_id',
						// 'customer_id',
						/*array(
								'name'=>'customer_id',
								'value'=>function($data)
								{
									$cust_name = Customer::model()->findByPk($data->customer_id);
									return 	$cust_name->name;
								}
							),*/
							array(
				         		 'name'=>'customer_id',
				         		 'value'=>function($data){
				         		 	if(isset($data->getcust->name))
				         		 	{
				         		 		return $data->getcust->name;
				         		 	}
				         		 }
			         		),
						// 'cash_type',
							array(
								'name'=>'cash_type',
								'value'=>function($data){
									if(!empty($data->cash_type))
									{
										if($data->cash_type == 1)
										{
											return "IN";
										}
										if($data->cash_type == 2)
										{
											return "OUT";
										}
									}
									else
									{
										return "-";
									}	
								}
							),

						// 'amount',
							array(
								'name'=>'amount',
								'value'=>function($data){
									$cash_amount = ltrim($data->amount, '-'); 
									// return number_format((float)$cash_amount, 3, '.', '');
									 return $cash_amount;
								}
							),
						array(
								'name'=>'gold_type',
								'value'=>function($data)
								{
									if(!empty($data->gold_type))
									{
										if($data->gold_type == 1)
										{
											return "IN";
										}
										if($data->gold_type == 2)
										{
											return "OUT";

										}
									}
									else
									{
										return "-";
									}
									
								}
							),
						// 'gold_amount',
						array(
							'name'=>'gold_amount',
							'value'=>function($data){
								$gold_amount = ltrim($data->gold_amount, '-'); 
								return number_format((float)$gold_amount, 3, '.', '');
								// return $gold_amount;
							}
						),
						// 'created_date',
						array(
						'name'=>'created_date',
						// 'htmlOptions'=>array('style'=>'text-align: center;', 'class'=>'zzz'),
						'value'=>function($data)
						{
							return $new_date = date('d-m-Y',strtotime($data->created_date)); 
						}
					),
						// 'is_deleted',
					),
				)); ?>
			</div>
		</div>
	</div>
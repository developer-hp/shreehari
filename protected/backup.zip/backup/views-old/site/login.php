<div class="block animation-fadeInQuick">
    <!-- Login Title -->
    <div class="block-title">
        <h2>Please Login</h2>
    </div>
    <!-- END Login Title -->

    <?php
    /* @var $this SiteController */
    /* @var $model LoginForm */
    /* @var $form CActiveForm  */

    $this->pageTitle = Yii::app()->name . ' - Login';
    $this->breadcrumbs = array(
        'Login',
    );
    ?>

    <?php
    $form = $this->beginWidget('CActiveForm', array(
        'id' => 'form-login',
        // 'enableClientValidation' => true,
        'htmlOptions' => array('class' => 'form-horizontal'),
        'clientOptions' => array(
            'validateOnSubmit' => true,
        ),
        'errorMessageCssClass'=>'help-block animation-slideUp form-error',
    ));
    ?>
    <div class="form-group">
        <?php echo $form->labelEx($model, 'username', array('class' => 'col-xs-12')); ?>
        <div class="col-xs-12">
            <?php echo $form->textField($model, 'username', array('class' => 'form-control')); ?>
            <?php //echo $form->error($model, 'username'); ?>
        </div>
    </div>

    <div class="form-group">
        <?php echo $form->labelEx($model, 'password', array('class' => 'col-xs-12')); ?>
        <div class="col-xs-12">
            <?php echo $form->passwordField($model, 'password', array('class' => 'form-control')); ?>
            <?php echo $form->error($model, 'password'); ?>
        </div>
    </div>

    
    <div class="form-group form-actions">
        <div class="col-xs-8">
            <label class="csscheckbox csscheckbox-primary">
                <?php echo $form->checkBox($model, 'rememberMe'); ?><span></span> <?php echo $form->label($model, 'rememberMe'); ?>
            </label>
        </div>
        <div class="col-xs-4 text-right">
                    <?php echo CHtml::submitButton('Log-in',array('class'=>'btn btn-effect-ripple btn-sm btn-success')); ?>
        </div>
    </div>
    <?php $this->endWidget(); ?>
</div>
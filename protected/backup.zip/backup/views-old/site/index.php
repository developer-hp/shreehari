<!--  <div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1>Home</h1>
            </div>
        </div>
        
    </div>
</div> -->


<div class="row">
    <div class="col-sm-6 col-lg-6">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-arrow-left text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong><span data-toggle="counter" data-to="2862">
                             <?php
                                    $date = date("Y-m-d");
                                 // echo  $date = date('Y-m-d',strtotime('Y-m-d'));
                                    $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and cash_type=1');
                                    $total_cash_in =0;
                                    foreach ($model as $key => $value)
                                    {
                                        $total_cash_in = $total_cash_in+$value->amount;
                                       /* echo $value->amount;
                                        echo "<br>";*/
                                    }
                                     echo $total_cash_in;
                                    ?>
                    </span></strong>
                </h2>
                <span class="text-muted">Today Cash In</span>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-lg-6">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-arrow-right text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong> <span data-toggle="counter" data-to="2862">
                          <?php
                            $date = date("Y-m-d");
                         // echo  $date = date('Y-m-d',strtotime('Y-m-d'));
                            $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and cash_type=2');
                            $total_cash_out =0;
                            foreach ($model as $key => $value)
                            {
                                $cash_amount = ltrim($value->amount, '-'); 
                                $total_cash_out = $total_cash_out+$cash_amount;
                            }
                           echo $total_cash_out;
                        ?>

                    </span></strong>
                </h2>
                <span class="text-muted">Today Cash Out</span>
            </div>
        </a>
    </div>
    <div class="col-sm-6 col-lg-6">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-arrow-left text-light-op"></i>
                    <!-- <i class="fas fa-coins"></i> -->
                </div>
                <h2 class="widget-heading h3 text">
                    <strong> <span data-toggle="counter" data-to="2862">
                        
                    <?php
                        $date = date("Y-m-d");
                     // echo  $date = date('Y-m-d',strtotime('Y-m-d'));
                        $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and gold_type=1');
                        $total_gold_in = 0;
                        foreach ($model as $key => $value)
                        {
                            $total_gold_in = $total_gold_in+$value->gold_amount;
                           /* echo $value->amount;
                            echo "<br>";*/
                        }
                         echo $total_gold_in;
                    ?>

                    </span></strong>
                </h2>
                <span class="text-muted">Today Gold In</span>
            </div>
        </a>
    </div>
    <div class="col-sm-6 col-lg-6" >
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-arrow-right text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong><span data-toggle="counter" data-to="2862">
                        
                         <?php
                            $date = date("Y-m-d");
                         // echo  $date = date('Y-m-d',strtotime('Y-m-d'));
                            $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and gold_type=2');
                            $total_gold_out = 0;
                            foreach ($model as $key => $value)
                            {
                                $gold_amount_change = ltrim($value->gold_amount, '-'); 
                                $total_gold_out = $total_gold_out+$gold_amount_change;
                            }
                           echo $total_gold_out;
                        ?>


                    </span></strong>
                </h2>
                <span class="text-muted">Today Gold Out</span>
            </div>
        </a>
    </div>

</div>
    
<!-- 

<div class="container">
        <div class="row">
            <div class="row">
                <div class="col-sm-3 " style="background-color: #fff; margin-left: 10px;  ">
                    <span class="widget">
                        <div class="widget-content widget-content-mini text-right clearfix">
                            <div class="widget-icon pull-left themed-background">
                                <i class="fa fa-money text-light-op"></i>
                            </div>
                            <h2 class="widget-heading h3">
                                <strong><span data-toggle="counter" data-to="2835">
                                    <?php
                                  /*  $date = date("Y-m-d");
                         
                                    $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0');
                                    $total_cash_in = "";
                                    foreach ($model as $key => $value)
                                    {
                                        $total_cash_in = $total_cash_in+$value->amount;
                                      
                                    }
                                    echo $total_cash_in;*/
                                    ?>

                                </span></strong>
                            </h2>
                            <span class="text-muted">

                                <?php
                                   //$date = date('Y-m-d',strtotime('2020-01-24'));
                                    // $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0');
                                    // print_r($model);die;

                                    //     // $cash_in = Cashevent::model()->findAllByAttributes(array('created_date'=>$date , 'is_deleted'=>0));
                                    //     print_r($cash_in);
                                    //     foreach ($cash_in as $key => $value)
                                    //     {
                                    //        print_r($value->id);
                                    //     }

                                    ?>
                            Cash IN</span>
                        </div>
                    </span>
                </div>
                <div class="col-sm-3 " style="background-color: #fff; margin-left: 10px;">
                     <span class="widget">
                        <div class="widget-content widget-content-mini text-right clearfix">
                            <div class="widget-icon pull-left themed-background">
                                <i class="gi gi-cardio text-light-op"></i>
                            </div>
                            <h2 class="widget-heading h3">
                                <strong><span data-toggle="counter" data-to="2835">2835</span></strong>
                            </h2>
                            <span class="text-muted">CASH OUT</span>
                        </div>
                   </span>
                </div>
                <div class="col-sm-3 " style="background-color: #fff; margin-left: 10px;">
                   <span class="widget">
                        <div class="widget-content widget-content-mini text-right clearfix">
                            <div class="widget-icon pull-left themed-background">
                                <i class="gi gi-cardio text-light-op"></i>
                            </div>
                            <h2 class="widget-heading h3">
                                <strong><span data-toggle="counter" data-to="2835">2835</span></strong>
                            </h2>
                            <span class="text-muted">GOLD IN</span>
                        </div>
                   </span>
                </div>
                <div class="col-sm-3" style="background-color: #fff; margin-left: 10px; margin-top: 10px;">
                   <span class="widget">
                        <div class="widget-content widget-content-mini text-right clearfix">
                            <div class="widget-icon pull-left themed-background">
                                <i class="gi gi-cardio text-light-op"></i>
                            </div>
                            <h2 class="widget-heading h3">
                                <strong><span data-toggle="counter" data-to="2835">2835</span></strong>
                            </h2>
                            <span class="text-muted">GOLD OUT</span>
                        </div>
                    </span>
                </div>  
            </div>
            </div>
        </div>
 -->
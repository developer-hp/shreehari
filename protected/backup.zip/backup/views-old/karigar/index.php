<?php
/* @var $this KarigarController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Karigars',
);

$this->menu=array(
	array('label'=>'Create Karigar', 'url'=>array('create')),
	array('label'=>'Manage Karigar', 'url'=>array('admin')),
);
?>

<h1>Karigars</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>

<div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1>View Customer #<?php echo $data->name; ?></h1>
            </div>
        </div>
        
    </div>
</div>
<?php
$d = Cashevent::model()->findAll(array('select'=>'sum(amount) as amount,sum(gold_amount) as gold_amount','condition'=>'is_deleted=0 and customer_id='.$data->id));

$g = $a = 0;
foreach ($d as $key => $value) {
	if($value->gold_amount)
	$g = $value->gold_amount;
	if($value->amount)
	$a = $value->amount;
}


?>
<div class="row">
    <div class="col-lg-4">
                                <div class="widget">
                                    <div class="widget-content themed-background-passion text-right clearfix">
                                        <a href="javascript:void(0)" class="pull-left">
                                            <img src="<?php echo Yii::app()->baseUrl?>/img/placeholders/avatars/avatar7@2x.jpg" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
                                        </a>
                                        <h3 class="widget-heading text-light"><?php echo $data->name; ?></h3>
                                        <h4 class="widget-heading text-light-op"><?php echo $data->mobile; ?></h4>
                                    </div>
                                    <div class="widget-content">
                                        <div class="row text-center">
                                            <div class="col-xs-6">
                                                <h3 class="widget-heading"><small>CASH</small><br><a href="javascript:void(0)" class="themed-color-passion"><?php echo $a; ?> INR</a></h3>
                                            </div>
                                            <div class="col-xs-6">
                                                <h3 class="widget-heading"><small>GOLD</small><br><a href="javascript:void(0)" class="themed-color-passion"><?php echo number_format($g,3); ?> gm</a></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
    <div class="col-lg-12">
        <!-- Partial Responsive Block -->
        <div class="block">
            <!-- Partial Responsive Title -->
            <div class="block-title">
                <h2>Cash/GOLD</h2>
            </div>
            <div class="row">
            
                            </div>


                            <div class="table-responsive">


<?php $this->widget('zii.widgets.grid.CGridView', array(
    'id'=>'item-grid',
    'itemsCssClass' => 'table table-striped table-bordered table-vcenter',
    'dataProvider'=>$model->search(),
    'filter'=>$model,
    'columns'=>array(
        // 'id',
        // 'id',
        'amount',
        'gold_amount',
    ),
)); ?>
</div>




</div>
</div>
</div>

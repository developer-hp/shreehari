<?php

class CustomerController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/main';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view_supllier','view_customer','view_karigar'),
				'users'=>array('@'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create_supplier','update_supplier','create_customer','create_karigar','update_customer','update_karigar','openpopup','save_cash_event'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform '	admin' and 'delete' actions
				'actions'=>array('list_supplier','delete','list_karigar','list_customer'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	public function actionSave_cash_event()
	{
		echo "<pre>";
		 print_r($_POST);
		die(); 
		$model = new Cashevent;
		if(isset($_POST['cust_id']))
		{
			$model->customer_id = $_POST['cust_id'];
		}
		
		if(isset($_POST['cash_type']))
		{
			$model->cash_type =  $_POST['cash_type'];
		}
		if(isset($_POST['gold_type']))
		{
			$model->gold_type =  $_POST['gold_type'];
		}


		if(isset($_POST['cash_type']) && $_POST['cash_type'] == 1)
		{
			$model->amount = $_POST['amount'];	
		}
		if(isset($_POST['gold_type']) && $_POST['gold_type'] == 1)
		{
			$model->gold_amount = $_POST['gold_amount'];	
		}	
		if(isset($_POST['cash_type']) && $_POST['cash_type'] == 2)
		{
			$model->amount = "-".$_POST['amount'];	
		}
		if(isset($_POST['gold_type']) && $_POST['gold_type'] == 2)
		{
			$model->gold_amount = "-".$_POST['gold_amount'];	
		}
		/* $transaction_id_random=$this->referral_code();
		$model->referral_code=$transaction_id_random; */
		$check = Cashevent::model()->find(array('order'=>'id DESC'));				
			$referral_code = $check->referral_code;
			$num_value = str_replace("INV","",$referral_code);
			$start = 'INV';
			if(isset($check->referral_code) && $check->referral_code != "")
			{
				$num=$num_value+1;
			}
			else
			{
				$num = 1;
			}
			$model->referral_code = 'INV'.str_pad( $num, 4, "0", STR_PAD_LEFT );

		if(isset($_POST['create_date']))
		{
			$model->created_date = date('Y-m-d',strtotime($_POST['create_date']));
		}
		if(isset($_POST['note']))
		{
			$model->narration = $_POST['note'];
		}
		$model->user_id = Yii::app()->user->getId();
		// $model->created_date = date('Y-m-d H:i:s');
		/*print_r($model);
		die();*/ 
		if($model->save(false))
		{
			$msg['msg'] = "Cash Add Successfully......";
			echo json_encode($msg);
		}

	}


	public function actionOpenpopup()
	{
		//print_r($_POST);
		// $cust_id = $_POST['cust_id'];
			$model = new Cashevent;
			// if(isset($_POST['cust_id']) && $_POST['cust_id']!='')
			// {
			// 	$model=$this->loadModel($_POST['cust_id']);								
			// }	
		// Uncomment the following line if AJAX validation is needed
		if(isset($_POST['ajax']) && $_POST['ajax']==='cashevent-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
		
		$this->renderPartial('addcash', array('model'=>$model), false,true);


		?>

	<?php
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView_supllier($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}
	public function actionView_customer($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}
	public function actionView_karigar($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate_supplier()
	{
		$model=new Customer;

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Customer']))
		{
			$model->attributes=$_POST['Customer'];
			if($model->save())
			{
				Yii::app()->user->setFlash('success', 'Insert successfully');
				// $this->redirect(array('view','id'=>$model->id));
				$this->redirect(array('list_supplier'));
			}
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	public function actionCreate_customer()
	{
		$model=new Customer;

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Customer']))
		{
			$model->attributes=$_POST['Customer'];
			if($model->save())
			{
				Yii::app()->user->setFlash('success', 'Insert successfully');
				// $this->redirect(array('view','id'=>$model->id));
				$this->redirect(array('list_customer'));
			}
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}


	public function actionCreate_karigar()
	{
		$model=new Customer;

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Customer']))
		{
			$model->attributes=$_POST['Customer'];
			if($model->save())
			{
				Yii::app()->user->setFlash('success', 'Insert successfully');
				// $this->redirect(array('view','id'=>$model->id));
				$this->redirect(array('list_karigar'));
			}
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}


	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */

	public function actionUpdate_supplier($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Customer']))
		{
			$model->attributes=$_POST['Customer'];
			if($model->save(false))
			{
				Yii::app()->user->setFlash('success', 'Updated successfully');
				// $this->redirect(array('view','id'=>$model->id));
				$this->redirect(array('list_supplier'));
			}
		}
		$this->render('update',array(
			'model'=>$model,
		));
	}


	public function actionUpdate_customer($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Customer']))
		{
			$model->attributes=$_POST['Customer'];
			if($model->save(false))
			{
				Yii::app()->user->setFlash('success', 'Updated successfully');
				// $this->redirect(array('view','id'=>$model->id));
				$this->redirect(array('list_customer'));
			}
		}
		$this->render('update',array(
			'model'=>$model,
		));
	}

	public function actionUpdate_karigar($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Customer']))
		{
			$model->attributes=$_POST['Customer'];
			if($model->save(false))
			{
				Yii::app()->user->setFlash('success', 'Updated successfully');
				// $this->redirect(array('view','id'=>$model->id));
				$this->redirect(array('list_karigar'));
			}
		}
		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */

	public function actionDelete($id)
	{
		$model = Customer::model()->findByPk($id);
			if($model)
			{
				$cash_model = Cashevent::model()->findAllByAttributes(array('customer_id'=>$id,'is_deleted'=>0));
			/*	echo "<pre>";
				print_r($cash_model);*/
				foreach ($cash_model as $key => $value) 
				{
					$value->is_deleted = 1;
					$value->save(false);
				}

				$model->is_deleted = 1;
				
				$model->save(false);

			}

		/*$this->loadModel($id)->delete();

		
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));*/
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Customer');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionList_supplier()
	{
		$model=new Customer('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Customer']))
			$model->attributes=$_GET['Customer'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	public function actionList_customer()
	{
		$model=new Customer('search_customer');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Customer']))
			$model->attributes=$_GET['Customer'];

		$this->render('customer_grid',array(
			'model'=>$model,
		));
	}

	public function actionList_karigar()
	{
		$model=new Customer('search_karigar');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Customer']))
			$model->attributes=$_GET['Customer'];

		$this->render('karigar_grid',array(
			'model'=>$model,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Customer the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Customer::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Customer $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='customer-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}

<?php

class CasheventController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/main';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','view_event'),
				'users'=>array('@'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','openpopup','add_new_cash','report','generate_excel','Generate_excel_new','findcustomer','list_supplier_event','list_customer_event','list_karigar_event','pdfexport'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','remove_record'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}


	public function actionPdfexport()
	{
	/*	print_r($_GET['id']);
		die(); */
		$id = $_GET['id'];
		$this->layout =false;
		include Yii::app()->basePath.'/extensions/mpdf/mpdf.php';
		ob_start(); 
		$model=Cashevent::model()->findByPk($id);
		// print_r($model);
		$cash_lods = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id));
		// print_r($cash_lods);
		$mpdf = new Mpdf();
        
        $mpdf->WriteHTML($this->render('exportpdf', array('model'=>$model,'cash_lods'=>$cash_lods), true));
      
        $mpdf->Output();		

	}
	public function actionOpenpopup()
	{
		//print_r($_POST);
		// $cust_id = $_POST['cust_id'];
			$model = new Cashevent;
			$selected_date = date("Y-m-d");
			$model->created_date = date('d-m-Y',strtotime($selected_date));
			// if(isset($_POST['cust_id']) && $_POST['cust_id']!='')
			// {
			// 	$model=$this->loadModel($_POST['cust_id']);								
			// }	
		// Uncomment the following line if AJAX validation is needed
			$model->scenario ='createrecord';
		if(isset($_POST['ajax']) && $_POST['ajax']==='cashevent-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
		
		$this->renderPartial('addcash', array('model'=>$model), false,true);

	}

	public function actionList_supplier_event()
	{
		/*echo "SSS";
		die();*/
		$model=new Cashlogs('search_event');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashlogs']))
			$model->attributes=$_GET['Cashlogs'];

		$this->render('cash_event',array(
			'model'=>$model,
		));
	}

	public function actionList_customer_event()
	{
		/*$model=new Cashevent('search_event');
		$model->unsetAttributes(); 
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];*/
		$model=new Cashlogs('search_event');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashlogs']))
			$model->attributes=$_GET['Cashlogs'];	
		$this->render('cash_event',array(
			'model'=>$model,
		));
	}

	public function actionList_karigar_event()
	{
	/*	$model=new Cashevent('search_event');
		$model->unsetAttributes(); 
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent']; */
		$model=new Cashlogs('search_event');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashlogs']))
			$model->attributes=$_GET['Cashlogs'];

		$this->render('cash_event',array(
			'model'=>$model,
		));
	}




	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		// echo $id;
		// die();
			$model = Cashlogs::model()->findByPk($id);
		$this->render('view',array(
			 'model'=>$model,
		));
	}

	public function actionView_event($id)
	{
		// echo $id;
		// die();
		$model_log = new Cashlogs('search_cash');
		$model_log->unsetAttributes();  
		$model = Cashevent::model()->findByPk($id);
		$this->render('view_event',array(
			 'model'=>$model,'model_log'=>$model_log
		));
	}




	public function actionFindcustomer()
	{
		/* print_r($_POST);
			die(); */
		if(isset($_POST['searchTerm']))
		{	
			$is_deleted = 0;
			$user_data = $_POST['searchTerm'];
			$criteria=new CDbCriteria;
			$criteria->condition='name like "%'. $user_data .'%" and is_deleted ="'.$is_deleted.'" ';
			/*print_r($criteria);
			die;*/
			$data = array();
			// $data[] = array("id"=>"","text"=>"All");
			if($user_data != "")
			{
				$model=Customer::model()->findAll($criteria);
			}
			else
			{
				$model = "";
			}
			if($model)
			{	
				$data[] = array("id"=>"All","text"=>"All");
				foreach ($model as $key => $value)
				{
				  $data[] = array("id"=>$value['id'], "text"=>$value['name']);
				}
			}
			else
			{
				$data[] = array("id"=>"All","text"=>"All");
			}

			
			/*while ($row = mysqli_fetch_array($model)) {    
			  $data[] = array("id"=>$row['id'], "text"=>$row['name']);
			}*/

			echo json_encode($data);
		}

		/*$user_data = $_POST['user_data'];
		$model = Customer::model()->findAllByAttributes(array('type'=>$user_data));
		$output = "<option value=''>---Select Customer---</option> <option value='all_cust'>All</option>";
		 foreach ($model as $key => $value) 
			 {
			 	$output .= '<option value="<?php $value->id; ?>">'.$value["name"].'</option>'; 
			 }

			   echo $output;*/

	}


	/*public function actionFindcustomer()
	{
		$user_data = $_POST['user_data'];
		$model = Customer::model()->findAllByAttributes(array('type'=>$user_data));
		// print_r($model);
		//$output = "<option value=''>---Select Customer---</option>";
		$output = "<option value=''>---Select Customer---</option> <option value='all_cust'>All</option>";
		 foreach ($model as $key => $value) 
			 {
			 	$output .= '<option value="<?php $value->id; ?>">'.$value["name"].'</option>'; 
			 }

			   echo $output;

	}*/

	public function actionReport()
	{
		$this->render('report');
	}
public function actionGenerate_excel_new()
	{


			// print_r($_POST);
		// die();
		$criteria=new CDbCriteria;
		$condition = "1=1";
		$sum_group = "";

		// "SELECT * ,sum(t.amount) as amount FROM cp_cash_logs t JOIN cp_cash_event ON t.cashevent_id=cp_cash_event.id JOIN cp_customer ON t.customer_id=cp_customer.id WHERE cp_cash_event.is_deleted=0 GROUP BY t.customer_id,t.type"

		$criteria->join = 'JOIN cp_cash_event ON t.cashevent_id=cp_cash_event.id JOIN cp_customer ON t.customer_id=cp_customer.id';

		$condition.=' and  cp_cash_event.is_deleted=0 ';
		if(isset($_POST['user_type']) && $_POST['user_type'] != "")
		{
		 	$condition .= ' AND cp_customer.type ="'.$_POST['user_type'].'"  ';
		}

		if(isset($_POST['customer_id']) && $_POST['customer_id'] != "All")
		{
		 	$condition .= ' and t.customer_id ="'.$_POST['customer_id'].'"';
		 	// $criteria->group = 't.type,t.cashevent_id';
		}
		else
		{
		 	$sum_group = 1;
		 	$criteria->group = ' t.customer_id';
		 	$criteria->select=' * ,sum(t.amount) as amount ';
		}

		/* if(isset($_POST['event_type']) && $_POST['event_type'] != "all_type")
		{
		 	$condition .= ' and t.type ="'.$_POST['event_type'].'"';
		 	// $criteria->group = 't.type,t.cashevent_id';
		} */

		 if(isset($_POST['start_date']) && $_POST['start_date'] != "")
		 {
		 	 $new_date = date('Y-m-d',strtotime($_POST['start_date']));
		 	 $end_date = date('Y-m-d',strtotime($_POST['end_date']));
		 	$condition .= ' and t.date BETWEEN "'.$new_date.' 00:00:00" AND "'.$end_date.' 23:59:59 "';
		 }
		/*	 $deleted = 0;
		 $condition .= ' and t.is_deleted ="'. $deleted.'"';  */
		 $criteria->condition = $condition;
		 $model=Cashlogs::model()->findAll($criteria);
		/* pr($model);
		 die; */

		 	$phpExcelPath = Yii::app()->basePath.'/vendor/phpexcel/PHPExcel/Classes';
			require_once($phpExcelPath . DIRECTORY_SEPARATOR . '../../PHPExcel.php');
		
			$objPHPExcel = new PHPExcel();

		    if ($sum_group == 1)
		    {
	    		$objPHPExcel->getActiveSheet()->getStyle("A1:B1")->getFont()->setBold(true);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		    }
		    else
		    {
		    	$objPHPExcel->getActiveSheet()->getStyle("A1:F1")->getFont()->setBold(true);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			     $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
		    }

		    if ($sum_group == 1)
		    {
		    	$objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A1', 'NAME')
                    ->setCellValue('B1', 'OUTSTANDING TOTAL');
		    }
		    else
		    {
		    	$objPHPExcel->setActiveSheetIndex(0)
	                ->setCellValue('A1', 'NAME')
	                ->setCellValue('B1', 'ITEM NAME')
	                ->setCellValue('C1', 'PAYMENT TYPE')
	                ->setCellValue('D1', 'AMOUNT')
	                ->setCellValue('E1', 'TOTAL AMOUNT')
	                ->setCellValue('F1', 'DATE');
		    }

		        $post_list = array();
          		$cash_total = 0;
          		$payment_type= "";
          		$item_name = "";
          		$main_amount = 0;
			    foreach ($model as $key => $value)
			    {

			    	$cash_total =$cash_total+$value->amount;

		    		$cust_nm = Customer::model()->findByPk($value->customer_id);
		    		$item_name = $value->note;
		    		if($value->type == 1)
		    		{
		    			$payment_type = "Cash";
		    		}
		    		if($value->type == 2)
		    		{
		    			$payment_type = "Gold";
		    		}
		    		if($value->type == 3)
		    		{
		    			$payment_type = "Bank";
		    		}
		    		if($value->type == 4)
		    		{
		    			$payment_type = "Card";
		    		}
		    		if($value->type == 5)
		    		{
		    			$payment_type = "Discount";
		    		}
		    		if($value->type == 6)
		    		{
		    			$payment_type = "";
		    		}
		    		if($value->date != "")
					{
						$convert_date =  date('d-m-Y',strtotime($value->date));
					}
					$main_amount = $value->amount;

		    		$post_list[] = array("Name"=>$cust_nm->name,"Item_name"=>$item_name,"Payment_type"=>$payment_type,"Amount"=>$main_amount,"Total_amount"=>$cash_total,"Date"=>$convert_date);	
			    }

			    $rowCount = 2;
	    		if($sum_group == 1)
	    		{
    				foreach($post_list as $post) 
		    		{
						$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowCount,$post['Name']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowCount,$post['Amount']);
		    			// $objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Gold_total']);
						$rowCount++;
					}
				}
				else
				{
					foreach($post_list as $post) 
		    		{
						$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowCount,$post['Name']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowCount,$post['Item_name']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Payment_type']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('D'.$rowCount,$post['Amount']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('E'.$rowCount,$post['Total_amount']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('F'.$rowCount,$post['Date']);
		    			// $objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Gold_total']);
						$rowCount++;
					}
				}

				header('Content-Type: application/vnd.ms-excel');	
					$filename="Event_Report";
					header('Content-Disposition: attachment;filename='.$filename.'.xls');
					header('Cache-Control: max-age=0');
					// If you're serving to IE 9, then the following may be needed
					header('Cache-Control: max-age=1');

					// If you're serving to IE over SSL, then the following may be needed
					// header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
					// header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
					header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
					// header ('Pragma: public'); // HTTP/1.0

					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$objWriter->save('php://output');


			    // pr($post_list);
		
	}	

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Cashevent;

		$cash_log = new Cashlogs;

		// Uncomment the following line if AJAX validation is needed
		$model->scenario ='createrecord';
		$this->performAjaxValidation($model);

		if(isset($_POST['Cashevent']))
		{
			// print_r($_POST);
			$check = Cashevent::model()->find(array('order'=>'id DESC'));	
			if(!empty($check))
			{
				$referral_code = $check->referral_code;
			}
			else
			{
				$referral_code = "INV00000";
			}			
			$num_value = str_replace("INV","",$referral_code);
			$start = 'INV';
			if(isset($check->referral_code) && $check->referral_code != "")
			{
				$num=$num_value+1;
			}
			else
			{
				$num = 1;
			}

			$model->referral_code = 'INV'.str_pad( $num, 5, "0", STR_PAD_LEFT );
			$model->created_date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
			$model->user_id = Yii::app()->user->getId();
			$model->customer_id = $_POST['Cashevent']['customer_id'];
			$model->narration = $_POST['Cashevent']['narration'];

			if($model->save(false))
			{
				// echo "<pre>";
				// print_r($_POST);die;
				if(isset($_POST['note']) && $_POST['note'] != "")
				{
					foreach ($_POST['note'] as $key => $value)
					{
						
							$amount=0;
							if(isset($_POST['amount'][$key]) && $_POST['amount'][$key]!='')
							{
								$amount="-".$_POST['amount'][$key];
							}
							
							$cash_log = new Cashlogs;
							$cash_log->cashevent_id = $model->id;
							$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
							$cash_log->note = $value;
							$cash_log->type = 6;
							$cash_log->amount =$amount; 
							$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
							$cash_log->status = 1;
							$cash_log->save(false);
						

					// $cash_log = new Cashlogs;
					/* echo "<pre>";
					print_r($cash_log);
					echo "<br>"; */
					/* print_r($value);
					echo "<br>"; */
					}
				}	

				if(isset($_POST['Cashevent']['amount']) && $_POST['Cashevent']['amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $model->id;
					$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
					// $cash_log->note = $value;
					$cash_log->type = 1;
					$cash_log->amount = $_POST['Cashevent']['amount'];
					/* if($_POST['Cashevent']['cash_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['amount'];	
					}
					if($_POST['Cashevent']['cash_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['amount'];	
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}

				if(isset($_POST['Cashevent']['gold_amount']) && $_POST['Cashevent']['gold_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $model->id;
					$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
					// $cash_log->note = $value;
					$cash_log->type = 2;
					$cash_log->amount = $_POST['Cashevent']['gold_amount'];
					/* if($_POST['Cashevent']['gold_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['gold_amount'];
					}
					if($_POST['Cashevent']['gold_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['gold_amount'];
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}


				if(isset($_POST['Cashevent']['bank_amount']) && $_POST['Cashevent']['bank_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $model->id;
					$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
					// $cash_log->note = $value;
					$cash_log->type = 3;
					$cash_log->amount = $_POST['Cashevent']['bank_amount'];
					/*if($_POST['Cashevent']['bank_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['bank_amount'];
					}
					if($_POST['Cashevent']['bank_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['bank_amount'];
					}*/
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}


				if(isset($_POST['Cashevent']['card_amount']) && $_POST['Cashevent']['card_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $model->id;
					$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
					// $cash_log->note = $value;
					$cash_log->type = 4;
					$cash_log->amount = $_POST['Cashevent']['card_amount'];
					/* if($_POST['Cashevent']['card_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['card_amount'];
					}
					if($_POST['Cashevent']['card_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['card_amount'];
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}

				if(isset($_POST['Cashevent']['discount_amount']) && $_POST['Cashevent']['discount_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $model->id;
					$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
					// $cash_log->note = $value;
					$cash_log->type = 5;
					$cash_log->amount = $_POST['Cashevent']['discount_amount'];
					/* if($_POST['Cashevent']['discount_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['discount_amount'];
					}
					if($_POST['Cashevent']['discount_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['discount_amount'];
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}


				if(isset($_POST['isAjaxRequest']) && $_POST['isAjaxRequest'] == 1) 
				{
				 	$msg['msg'] = "Cash Add Successfully......";
					echo json_encode($msg);
					die;
				}
				else
				{
					Yii::app()->user->setFlash('success', 'Insert successfully');
					$this->redirect(array('admin'));
					// $this->redirect(array('view','id'=>$model->id));
				}

				// Yii::app()->user->setFlash('success', 'Insert successfully');
				// $this->redirect(array('view','id'=>$model->id));
			}
			


		}

		$this->render('create',array(
			'model'=>$model,'cash_log'=>$cash_log
		));
	}


	/* function referral_code()
	{
		$chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			$unique_number = "";
			for ($i = 0; $i < 10; $i++) {
			    $unique_number .= $chars[mt_rand(0, strlen($chars)-1)];
			}

	    // $unique_number = rand(100000, 999999);
	   	$exists=Cashevent::model()->findbyattributes(array("referral_code"=>$unique_number));
	    if ($exists){
	        $results =$this->referral_code();
	    }
	     else{
	            $results = $unique_number;
	        return $results;
	     }
	} */

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */

	public function actionAdd_new_cash()
	{	
		//	echo "<pre>";	
		// print_r($_POST);
		$cust_id = Cashevent::model()->findByPk($_POST['Cashevent']['customer_id']);
		// echo $cust_id->customer_id;
		//die();

			// if(isset($_POST['note']))
			// 	{
			// 		foreach ($_POST['note'] as $key => $value)
			// 		{
			// 			$cash_log = new Cashlogs;
			// 			$cash_log->cashevent_id = $_POST['Cashevent']['customer_id'];
			// 			$cash_log->customer_id = $cust_id->customer_id;
			// 			$cash_log->note = $value;
			// 			$cash_log->type = 6;
			// 			$cash_log->amount = "-".$_POST['amount'][$key];
			// 			$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
			// 			$cash_log->status = 1;
			// 			$cash_log->save(false);
			// 		// $cash_log = new Cashlogs;
			// 		/* echo "<pre>";
			// 		print_r($cash_log);
			// 		echo "<br>"; */
			// 		/* print_r($value);
			// 		echo "<br>"; */
			// 		}
			// 	}	

				if(isset($_POST['Cashevent']['amount']) && $_POST['Cashevent']['amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $_POST['Cashevent']['customer_id'];
					$cash_log->customer_id = $cust_id->customer_id;
					// $cash_log->note = $value;
					$cash_log->type = 1;
					$cash_log->amount = $_POST['Cashevent']['amount'];
					/* if($_POST['Cashevent']['cash_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['amount'];	
					}
					if($_POST['Cashevent']['cash_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['amount'];	
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}

				if(isset($_POST['Cashevent']['gold_amount']) && $_POST['Cashevent']['gold_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $_POST['Cashevent']['customer_id'];
					$cash_log->customer_id = $cust_id->customer_id;
					// $cash_log->note = $value;
					$cash_log->type = 2;
					$cash_log->amount = $_POST['Cashevent']['gold_amount'];
					/* if($_POST['Cashevent']['gold_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['gold_amount'];
					}
					if($_POST['Cashevent']['gold_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['gold_amount'];
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}


				if(isset($_POST['Cashevent']['bank_amount']) && $_POST['Cashevent']['bank_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $_POST['Cashevent']['customer_id'];
					$cash_log->customer_id = $cust_id->customer_id;
					// $cash_log->note = $value;
					$cash_log->type = 3;
					$cash_log->amount = $_POST['Cashevent']['bank_amount'];
					/*if($_POST['Cashevent']['bank_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['bank_amount'];
					}
					if($_POST['Cashevent']['bank_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['bank_amount'];
					}*/
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}


				if(isset($_POST['Cashevent']['card_amount']) && $_POST['Cashevent']['card_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $_POST['Cashevent']['customer_id'];
					$cash_log->customer_id = $cust_id->customer_id;
					// $cash_log->note = $value;
					$cash_log->type = 4;
					$cash_log->amount = $_POST['Cashevent']['card_amount'];
					/* if($_POST['Cashevent']['card_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['card_amount'];
					}
					if($_POST['Cashevent']['card_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['card_amount'];
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}

				if(isset($_POST['Cashevent']['discount_amount']) && $_POST['Cashevent']['discount_amount'] != "")
				{
					$cash_log = new Cashlogs;
					$cash_log->cashevent_id = $_POST['Cashevent']['customer_id'];
					$cash_log->customer_id = $cust_id->customer_id;
					// $cash_log->note = $value;
					$cash_log->type = 5;
					$cash_log->amount = $_POST['Cashevent']['discount_amount'];
					/* if($_POST['Cashevent']['discount_type'] == 1)
					{
						$cash_log->amount = $_POST['Cashevent']['discount_amount'];
					}
					if($_POST['Cashevent']['discount_type'] == 2)
					{
						$cash_log->amount = "-".$_POST['Cashevent']['discount_amount'];
					} */
					$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
					$cash_log->status = 0;
					// echo "SSSS";
					$cash_log->save(false);
					// print_r($cash_log);
				}

				if(isset($_POST['isAjaxRequest']) && $_POST['isAjaxRequest'] == 1) 
				{
				 	$msg['msg'] = "Cash Add Successfully......";
					echo json_encode($msg);
					die;
				}

	}

	public function actionUpdate($id)
	{

		$model=$this->loadModel($id);
		
		$model->created_date = date('d-m-Y',strtotime($model->created_date));
		$cash_log_type = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id,'type'=>1));
		$gold_log_type = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id,'type'=>2));
		$bank_log_type = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id,'type'=>3));
		$card_log_type = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id,'type'=>4));
		$dis_log_type = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id,'type'=>5));

		$cash_log_model = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id,'type'=>6));
		
		// print_r($cash_log_model);
		// die();
	/*	if(!empty($cash_log_type))
		{
			if ($cash_log_type->amount > 0)
			{
				$model->cash_type = 1;
			
			}
			if ($cash_log_type->amount < 0)
			{
				$model->cash_type = 2;
			}
			$new_cash_amount=ltrim($cash_log_type->amount,'-'); 
			$model->amount=$new_cash_amount;
		}

		if(!empty($gold_log_type))
		{
			if ($gold_log_type->amount > 0)
			{
				$model->gold_type= 1;
			
			}
			if ($gold_log_type->amount < 0)
			{
				$model->gold_type= 2;
			}

			$new_gold_amount=ltrim($gold_log_type->amount,'-'); 
			$model->gold_amount=$new_gold_amount;
		}

		if(!empty($bank_log_type))
		{
			if ($bank_log_type->amount > 0)
			{
				$model->bank_type= 1;
			}
			if ($bank_log_type->amount < 0)
			{
				
				$model->bank_type= 2;
			}
			$new_bank_amount=ltrim($bank_log_type->amount,'-'); 
			$model->bank_amount=$new_bank_amount;
		}

		if(!empty($card_log_type))
		{	
			if ($card_log_type->amount > 0)
			{
				$model->card_type= 1;
			
			}
			if ($card_log_type->amount < 0)
			{
				$model->card_type= 2;
			}

			$new_card_amount=ltrim($card_log_type->amount,'-'); 
			$model->card_amount=$new_card_amount;
		}

		if(!empty($dis_log_type))
		{
			if ($dis_log_type->amount > 0)
			{
				$model->discount_type= 1;
			
			}
			if ($dis_log_type->amount < 0)
			{
				$model->discount_type= 2;
			}
			$new_dis_amount=ltrim($dis_log_type->amount,'-'); 
			$model->discount_amount=$new_dis_amount;
		}*/

		// $cash_log_model->amount = ltrim($cash_log_model->amount,'-');
		
		/* print_r($cash_log_type);
		die(); */
		/*print_r($model);
		die();*/
		/*$model->amount=ltrim($model->amount, '-'); 

		$model->gold_amount=ltrim($model->gold_amount, '-'); */ 

		// $this->performAjaxValidation($model);

		if(isset($_POST['Cashevent']))
		{
			//  echo "<pre>";
			// print_r($_POST);
			// die(); 
			
			$cash_log_delete = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id));
			foreach ($cash_log_delete as $key => $value) 
			{
				$value->delete();	
			}

			$model->created_date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
			$model->user_id = Yii::app()->user->getId();
			$model->customer_id = $_POST['Cashevent']['customer_id'];
			$model->narration = $_POST['Cashevent']['narration'];
			if($model->save(false))
			{
				if(isset($_POST['note']) && $_POST['note'] != "")
				{
					foreach ($_POST['note'] as $key => $value)
					{
						$amount=0;
						if(isset($_POST['amount'][$key]) && $_POST['amount'][$key]!='')
						{
							$amount="-".$_POST['amount'][$key];
						}
						$cash_log = new Cashlogs;
						$cash_log->cashevent_id = $model->id;
						$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
						$cash_log->note = $value;
						$cash_log->type = 6;
						$cash_log->amount = $amount;
						$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
						$cash_log->status = 1;
						$cash_log->save(false);
					}
				}


				if(isset($_POST['Cashevent']['amount']))
				{
					foreach ($_POST['Cashevent']['amount'] as $key => $value_cash)
					{
						/*print_r($value_cash);
						die();*/
						if($value_cash != "")
						{
							$cash_log = new Cashlogs;
							$cash_log->cashevent_id = $model->id;
							$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
							$cash_log->type = 1;
							$cash_log->amount =  $value_cash;
							$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
							$cash_log->save(false);
						}
					}
				}


				if(isset($_POST['Cashevent']['gold_amount']))
				{
					foreach ($_POST['Cashevent']['gold_amount'] as $key => $value_gold)
					{
						if($value_gold != "")
						{
							$cash_log = new Cashlogs;
							$cash_log->cashevent_id = $model->id;
							$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
							$cash_log->type = 2;
							$cash_log->amount =  $value_gold;
							$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
							$cash_log->save(false);
						}
					}
				}

				if(isset($_POST['Cashevent']['bank_amount']))
				{
					foreach ($_POST['Cashevent']['bank_amount'] as $key => $value_bank)
					{
						if($value_bank != "")
						{
							$cash_log = new Cashlogs;
							$cash_log->cashevent_id = $model->id;
							$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
							$cash_log->type = 3;
							$cash_log->amount =  $value_bank;
							$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
							$cash_log->save(false);
						}
					}
				}

				if(isset($_POST['Cashevent']['card_amount']))
				{
					foreach ($_POST['Cashevent']['card_amount'] as $key => $value_card)
					{
						if($value_card != "")
						{
							$cash_log = new Cashlogs;
							$cash_log->cashevent_id = $model->id;
							$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
							$cash_log->type = 4;
							$cash_log->amount =  $value_card;
							$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
							$cash_log->save(false);
						}
					}
				}


				if(isset($_POST['Cashevent']['discount_amount']))
				{
					foreach ($_POST['Cashevent']['discount_amount'] as $key => $value_dis)
					{
						if($value_dis != "")
						{
							$cash_log = new Cashlogs;
							$cash_log->cashevent_id = $model->id;
							$cash_log->customer_id = $_POST['Cashevent']['customer_id'];
							$cash_log->type = 5;
							$cash_log->amount =  $value_dis;
							$cash_log->date = date('Y-m-d',strtotime($_POST['Cashevent']['created_date']));
							$cash_log->save(false);
						}
					}
				}


				Yii::app()->user->setFlash('success', 'Updated successfully');
				$this->redirect(array('admin'));
				// $this->redirect(array('view','id'=>$model->id));
			}

		}
		$this->render('update',array(
			'model'=>$model,'cash_log_model'=>$cash_log_model,'cash_log_type'=>$cash_log_type,'gold_log_type'=>$gold_log_type,'bank_log_type'=>$bank_log_type,'card_log_type'=>$card_log_type,'dis_log_type'=>$dis_log_type
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */

	public function actionDelete($id)
	{
		/*echo $id;
		die;*/
		$model = Cashevent::model()->findByPk($id);
			if($model)
			{
				$cash_log_delete = Cashlogs::model()->findAllByAttributes(array('cashevent_id'=>$id));
				foreach ($cash_log_delete as $key => $value_del)
				{
					$value_del->delete();	
				}
				$model->is_deleted = 1;
				$model->save(false);

			}
	}


	 public function actionRemove_record()
    {
    	// print_r($_POST);
    	$delete_id = $_POST['delete_id'];
    	$model = Cashlogs::model()->findByPk($delete_id);
    	// print_r($model);
    	   $model->delete(); 
    	echo 1;
    }

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{

		$model=new Cashevent('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];

		$this->render('admin',array(
			'model'=>$model,
		));
		/* $dataProvider=new CActiveDataProvider('Cashevent');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		)); */
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Cashevent('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Cashevent the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Cashevent::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Cashevent $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='cashevent-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}

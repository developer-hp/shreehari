<?php

class SiteController extends Controller {

    /**
     * Declares class-based actions.
     */
    public function actions() {
        return array(
            // captcha action renders the CAPTCHA image displayed on the contact page
            'captcha' => array(
                'class' => 'CCaptchaAction',
                'backColor' => 0xFFFFFF,
            ),
            // page action renders "static" pages stored under 'protected/views/site/pages'
            // They can be accessed via: index.php?r=site/page&view=FileName
            'page' => array(
                'class' => 'CViewAction',
            ),
        );
    }
    public function actionSend()
    {
        $user =  User::model()->findAll('(password is null OR password="") and deleted=0');

        // print_r($user); die;

        $appsetting = $this->getsettings();
        foreach ($user as $key => $model) {

            $password = $this->randomPassword();
            $model->password = md5($password);
            $model->save(false);
        
            $mailinfo = $appsetting['REGISTER_MAIL_CONTENT'];
            $link = Yii::app()->createAbsoluteUrl('site/login');
            $mailinfo = str_replace(array('{{name}}','{{$link}}','{{$username}}','{{$password}}'), array($model->name,$link,$model->email,$password), $mailinfo);
            $mailinfo = str_replace(array('{{name}}','{{$link}}','{{$username}}','{{$password}}'), array("","","",""), $mailinfo);
            $subject = $appsetting['REGISTER_MAIL_SUBJECT'];
            $mail = new YiiMailer('message', array('message' => $mailinfo));
            $mail->setFrom(Yii::app()->params['adminEmail'], $appsetting['APP_NAME']);
            $mail->setTo($model->email);
            $mail->setBody($mailinfo);
            $mail->setSubject($subject);
            if($mail->send())
            {

            }
        }
        Yii::app()->user->setFlash('success', 'Sent successfully');
        $this->redirect(array('user/index'));
    }
    public function actionForm($id)
    {
        $questions = Questions::model()->findAll('form_id='.$id);

        $model=Forms::model()->findByPk($id);
        if($model===null)
            throw new CHttpException(404,'The requested page does not exist.');

        // Answer
        if(isset($_POST['answer']))
        {
            $answer_id = md5(time().'-'.Yii::app()->user->id);
            foreach ($_POST['answer'] as $key => $value) {
                $q = new Answer;
                $q->form_id = $model->id;
                $q->user_id = Yii::app()->user->id;
                $q->question_id = $key;
                $q->answer_id = $answer_id;
                $q->answer = $value;
                $q->save();
            }
            $this->redirect(array('result','aid'=>$answer_id,'t'=>0));
        }


        $this->render('form',array(
            'model'=>$model,
            'questions'=>$questions,
        ));
    }
    public function actionResult($aid,$t)
    {
        $a = Answer::model()->findAll(array('condition'=>'answer_id="'.$aid.'"'));
        $fid = $a[0]['form_id'];

        $output = Output::model()->find(array('condition'=>'form_id='.$fid.' and id<>'.$t,'order'=>'rand()'));
        $text = "";
        if($output){
            $text = $output->outputs;
            $t = $output->id;
        }

        foreach ($a as $key => $value) {
            $text = str_replace('{{question'.($key+1).'}}', $value->answer, $text);
            $text = str_replace('{{question'.($key+1).'}}', "", $text);
        }
        $this->render('result',array(
            't'=>$t,
            'aid'=>$aid,
            'text'=>$text,
        ));
    }
    public function actionIndex() {
        $id = Yii::app()->user->id;
        if (!$id) {
            $this->redirect(array('login'));
        }
        $this->render('index');
    }


    
    
    /**
     * This is the action to handle external exceptions.
     */
    public function actionError() {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest)
                echo $error['message'];
            else
                $this->render('error', $error);
        }
    }

    /**
     * Displays the contact page
     */
    public function actionContact() {
        $model = new ContactForm;
        if (isset($_POST['ContactForm'])) {
            $model->attributes = $_POST['ContactForm'];
            if ($model->validate()) {
                $name = '=?UTF-8?B?' . base64_encode($model->name) . '?=';
                $subject = '=?UTF-8?B?' . base64_encode($model->subject) . '?=';
                $headers = "From: $name <{$model->email}>\r\n" .
                        "Reply-To: {$model->email}\r\n" .
                        "MIME-Version: 1.0\r\n" .
                        "Content-Type: text/plain; charset=UTF-8";

                mail(Yii::app()->params['adminEmail'], $subject, $model->body, $headers);
                Yii::app()->user->setFlash('contact', 'Thank you for contacting us. We will respond to you as soon as possible.');
                $this->refresh();
            }
        }
        $this->render('contact', array('model' => $model));
    }

    /**
     * Displays the login page
     */
    
    public function actionLogin() {
        $model = new LoginForm;
        $this->layout = 'login';

        $id = Yii::app()->user->id;
        if ($id) {
            $this->redirect(Yii::app()->user->returnUrl);
        }

        // if it is ajax validation request
        // if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
        // {
        // 	echo CActiveForm::validate($model);
        // 	Yii::app()->end();
        // }
        // collect user input data
        if (isset($_POST['LoginForm'])) {
            $model->attributes = $_POST['LoginForm'];
            // validate user input and redirect to the previous page if valid
            if ($model->validate() && $model->login()){
                $this->redirect(Yii::app()->user->returnUrl);
            }
        }
        // display the login form
        $this->render('login', array('model' => $model));
    }

    /**
     * Logs out the current user and redirect to homepage.
     */
    public function actionLogout() {
        Yii::app()->user->logout();
        $this->redirect(Yii::app()->homeUrl);
    }
    protected function performAjaxValidation($model)
    {
        if(isset($_POST['ajax']) && $_POST['ajax']==='event-form')
        {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }

}

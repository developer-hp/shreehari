<?php

class CasheventController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/main';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('@'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','report','generate_excel','findcustomer','list_supplier_event','list_customer_event','list_karigar_event'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}


	public function actionList_supplier_event()
	{
		/*echo "SSS";
		die();*/
		$model=new Cashevent('search_event');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];

		$this->render('cash_event',array(
			'model'=>$model,
		));
	}

	public function actionList_customer_event()
	{
		$model=new Cashevent('search_event');
		$model->unsetAttributes(); 
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];

		$this->render('cash_event',array(
			'model'=>$model,
		));
	}

	public function actionList_karigar_event()
	{
		$model=new Cashevent('search_event');
		$model->unsetAttributes(); 
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];

		$this->render('cash_event',array(
			'model'=>$model,
		));
	}




	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}


	public function actionFindcustomer()
	{

		/* print_r($_POST);
			die();*/
		if(isset($_POST['searchTerm']))
		{	
			$user_data = $_POST['searchTerm'];
			$criteria=new CDbCriteria;
			$criteria->condition='name like "%'. $user_data .'%"';
			/*print_r($criteria);
			die;*/
			$data = array();
			// $data[] = array("id"=>"","text"=>"All");
			if($user_data != "")
			{
				$model=Customer::model()->findAll($criteria);
			}
			else
			{
				$model = "";
			}
			if($model)
			{	
				$data[] = array("id"=>"All","text"=>"All");
				foreach ($model as $key => $value)
				{
				  $data[] = array("id"=>$value['id'], "text"=>$value['name']);
				}
			}
			else
			{
				$data[] = array("id"=>"All","text"=>"All");
			}

			
			/*while ($row = mysqli_fetch_array($model)) {    
			  $data[] = array("id"=>$row['id'], "text"=>$row['name']);
			}*/

			echo json_encode($data);
		}

		/*$user_data = $_POST['user_data'];
		$model = Customer::model()->findAllByAttributes(array('type'=>$user_data));
		$output = "<option value=''>---Select Customer---</option> <option value='all_cust'>All</option>";
		 foreach ($model as $key => $value) 
			 {
			 	$output .= '<option value="<?php $value->id; ?>">'.$value["name"].'</option>'; 
			 }

			   echo $output;*/

	}


	/*public function actionFindcustomer()
	{
		$user_data = $_POST['user_data'];
		$model = Customer::model()->findAllByAttributes(array('type'=>$user_data));
		// print_r($model);
		//$output = "<option value=''>---Select Customer---</option>";
		$output = "<option value=''>---Select Customer---</option> <option value='all_cust'>All</option>";
		 foreach ($model as $key => $value) 
			 {
			 	$output .= '<option value="<?php $value->id; ?>">'.$value["name"].'</option>'; 
			 }

			   echo $output;

	}*/

	public function actionReport()
	{
		$this->render('report');
	}

	public function actionGenerate_excel()
	{
	/*	 print_r($_POST);
		 die();*/
		 $criteria=new CDbCriteria;
		 $condition = "1=1";
		 $sum_group = "";


		// print_r($_POST); die;
		 $criteria->join = 'JOIN cp_customer ON t.customer_id=cp_customer.id';

		 if(isset($_POST['user_type']) && $_POST['user_type'] != "")
		 {
		 	// $criteria->condition='type='.$_POST['user_type'];
		 	// $criteria->addCondition('type ="'.$_POST['user_type'].'"');
		 	$condition .= ' AND type ="'.$_POST['user_type'].'"  ';
		 }
		  
		 if(isset($_POST['event_type']) && $_POST['event_type'] != "")
		 {
		 	if($_POST['event_type'] == 1)
		 	{
		 		// $new_type_cash = 2;
			    // $condition .= ' and cash_type ="'.$_POST['event_type'].'"';
			    // $condition .= ' and cash_type ="'.$_POST['event_type'].'" or cash_type ="'.$new_type_cash.'"';
			  
		 	}

		 	if($_POST['event_type'] == 2)
		 	{
		 	    // echo "AAA";
			    // $condition .= ' and gold_type ="'.$_POST['event_type'].'"';
		 	}
		 	// if($_POST['evevt_type'] == "all_type")
		 	// {
		 	// 	// $criteria->addCondition('gold_type ="'.$_POST['evevt_type'].'"');
		    //    // $criteria->addCondition('gold_type ="'.$_POST['evevt_type'].'"');
		 	// }
			// $condition = $_POST['evevt_type'];
		 }
		if(isset($_POST['customer_id']) && $_POST['customer_id'] != "All")
		{
			// $criteria->condition='customer_id='.$_POST['customer_id'];
		 	$condition .= ' and customer_id ="'.$_POST['customer_id'].'"';
		 }
		 else
		 {
		 	
		 	$sum_group = 1;
		 	$criteria->group = 't.customer_id';
		 	$criteria->select=' * ,sum(gold_amount) as gold_amount';
		 	$criteria->select=' * ,sum(amount) as amount';
		 }
		 // print_r($_POST);die;
		 if(isset($_POST['start_date']) && $_POST['start_date'] != "")
		 {
		 	 $new_date = date('Y-m-d',strtotime($_POST['start_date']));
		 	 $end_date = date('Y-m-d',strtotime($_POST['end_date']));
		 	$condition .= ' and t.created_date BETWEEN "'.$new_date.' 00:00:00" AND "'.$end_date.' 23:59:59 "';
			// $condition= $_POST['start_date'];
		 }
		 /*if($_POST['end_date'])
		 {
			$condition = $_POST['end_date'];	
		 }*/
		 $deleted = 0;
		 // echo $condition; die;
		 // $criteria->addCondition('t.is_deleted ="'.$deleted.'"');
		 $condition .= ' and t.is_deleted ="'. $deleted.'"';
		 $criteria->condition = $condition;
			/* echo "<pre>";
			  print_r($criteria);
			  die;*/
		$model=Cashevent::model()->findAll($criteria);
	/*	echo "<pre>";
		print_r($model);
		die; */
		// print_r($_POST);
 	    $phpExcelPath =yii::app()->basePath.'/vendor/PHPExcel-1.8/Classes/';
		require_once($phpExcelPath . DIRECTORY_SEPARATOR . 'PHPExcel.php');
		/*echo $phpExcelPath;
		die();*/
		$objPHPExcel = new PHPExcel();

		  /* $objPHPExcel->getActiveSheet()->getStyle("A1:H1")->getFont()->setBold(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
		 	$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12); */

		    if ($sum_group == 1)
		    {
	     	    $objPHPExcel->getActiveSheet()->getStyle("A1:C1")->getFont()->setBold(true);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
			    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
		    }
		    else
		    {
		    	if($_POST['event_type'] == 1 OR $_POST['event_type'] == 2)
				{
			        $objPHPExcel->getActiveSheet()->getStyle("A1:E1")->getFont()->setBold(true);
			        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
		    	    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
				}
				else
				{

		    	    $objPHPExcel->getActiveSheet()->getStyle("A1:H1")->getFont()->setBold(true);
		    	    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
		    	    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
				    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
				}
		    }
		    if ($sum_group == 1)
		    {
				$objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A1', 'NAME')
                    ->setCellValue('B1', 'CASH TOTAL')
                    ->setCellValue('C1', 'GOLD TOTAL');
            }
            else
            {


            	if($_POST['event_type'] == 1)
				{
					$objPHPExcel->setActiveSheetIndex(0)
	                ->setCellValue('A1', 'NAME')
	                ->setCellValue('B1', 'CASH IN')
	                ->setCellValue('C1', 'CASH OUT')
	                ->setCellValue('D1', 'CASH TOTAL')
	                ->setCellValue('E1', 'DATE');
				}
			 	else if($_POST['event_type'] == 2)
				{
					$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A1', 'NAME')
	                ->setCellValue('B1', 'GOLD IN')
	                ->setCellValue('C1', 'GOLD OUT')
	                ->setCellValue('D1', 'GOLD TOTAL')
	                ->setCellValue('E1', 'DATE');
				}
				else
				{
	            	$objPHPExcel->setActiveSheetIndex(0)
		                ->setCellValue('A1', 'NAME')
		                ->setCellValue('B1', 'CASH IN')
		                ->setCellValue('C1', 'CASH OUT')
		                ->setCellValue('D1', 'CASH TOTAL')
		                ->setCellValue('E1', 'GOLD IN')
		                ->setCellValue('F1', 'GOLD OUT')
		                ->setCellValue('G1', 'GOLD TOTAL')
		                ->setCellValue('H1', 'DATE');
	            }
            }
                        $post_list = array();
                        $cash_total="";
                        $gold_total="";
                        foreach ($model as $key => $value) 
                        {
			    			$cash_in = $cash_out = "";
			    			$gold_in = $gold_out = "";

			    			$cust_nm = Customer::model()->findByPk($value['customer_id']);

			    					if($sum_group == 1)
			    					{
			    						$cash_total=$value->amount;
			    					/*	echo "<br>";*/
                        				$gold_total= $value->gold_amount;
			    						
			    						if($value->amount > 0)
				    					{
				    						$cash_amount = ltrim($value->amount,'-');
				    						$cash_in = $cash_amount;
				    						// $cash_total=$cash_total+$cash_in;
				    					 /* echo $cash_total;
				    					 	echo "<br>";*/
				    					}
				    					else
				    					{
				    						$cash_amount_sub = $value->amount*(-1);
				    						// $cash_amount_sub = ltrim($value->amount*(-1),'-');
				    						$cash_out = $cash_amount_sub;
				    						// $cash_total=$cash_total-$cash_out;
				    						// echo $cash_total;
				    					}
				    					if($value->gold_amount > 0)
				    					{
				    						$cash_amount_add = ltrim($value->gold_amount,'-');
				    						$gold_in = $cash_amount_add;
				    						// $gold_total= $gold_total+$gold_in;
				    					}
				    					else
				    					{ 
				    						$gold_amount_sub = $value->gold_amount*(-1);
				    						// $gold_amount_sub = ltrim($value->gold_amount*(-1),'-');
				    						// echo $value->gold_amount*(-1);
				    						// die();
				    						$gold_out = $gold_amount_sub;
				    						// $gold_total = $gold_total-$gold_out;
				    					}
				    					
				    					if($value->created_date != "")
				    					{
				    						$convert_date =  date('d-m-Y',strtotime($value->created_date));
				    					}
			    					}
			    					else
			    					{
			    						if($_POST['event_type'] != 2)
				    					{

				    						if($value->amount > 0)
					    					{
					    						$cash_amount = ltrim($value->amount,'-');
					    						$cash_in = $cash_amount;
					    						$cash_total=$cash_total+$cash_in;
					    					/*	echo $cash_total;
					    						echo "<br>";*/
					    					}
					    					else
					    					{
					    						/*echo "AAAA";
					    						die;*/
					    						$cash_amount_sub = $value->amount*(-1);
					    						// $cash_amount_sub = ltrim($value->amount*(-1),'-');
					    						$cash_out = $cash_amount_sub;
					    						$cash_total=$cash_total-$cash_out;
					    						// echo $cash_total;

					    					}
					    				}	
				    					if($_POST['event_type'] != 1)
				    					{	
					    					if($value->gold_amount > 0)
					    					{
					    						$cash_amount_add = ltrim($value->gold_amount,'-');
					    						$gold_in = $cash_amount_add;
					    						$gold_total= $gold_total+$gold_in;
					    					}
					    					else
					    					{ 
					    						$gold_amount_sub = $value->gold_amount*(-1);
					    						// $gold_amount_sub = ltrim($value->gold_amount*(-1),'-');
					    						//echo $gold_amount_sub;
					    						$gold_out = $gold_amount_sub;
					    						$gold_total = $gold_total-$gold_out;
					    					}
				    					}
				    					
				    					if($value->created_date != "")
				    					{
				    						$convert_date =  date('d-m-Y',strtotime($value->created_date));
				    					}
				    				}
				    				/*echo $cash_in;
				    				echo "he";*/
			    			$post_list[] = array("Name"=>$cust_nm->name,"Case_in"=>$cash_in,"Case_out"=>$cash_out,"Cash_total"=>$cash_total,"Gold_in"=>$gold_in,"Gold_out"=>$gold_out,"Gold_total"=>$gold_total,"Date"=>$convert_date);
    		         }
    		          /* die;*/
    		$rowCount = 2;
    		if($sum_group == 1)
    		{
    				foreach($post_list as $post) 
		    		{
		    			$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowCount,$post['Name']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowCount,$post['Cash_total']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Gold_total']);
						$rowCount++;
						/*print_r($post);
						echo "<br>";*/
    			}
    		}
    		else
    		{
	    		foreach($post_list as $post) 
	    		{
	    			if($_POST['event_type'] == 1)
					{
						$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowCount,$post['Name']);
	    				$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowCount,$post['Case_in']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Case_out']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('D'.$rowCount,$post['Cash_total']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('E'.$rowCount,$post['Date']);
						$rowCount++;
					}
					else if($_POST['event_type'] == 2)
					{
						$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowCount,$post['Name']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowCount,$post['Gold_in']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Gold_out']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('D'.$rowCount,$post['Gold_total']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('E'.$rowCount,$post['Date']);
						$rowCount++;
					}
					else
					{
						$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowCount,$post['Name']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowCount,$post['Case_in']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowCount,$post['Case_out']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('D'.$rowCount,$post['Cash_total']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('E'.$rowCount,$post['Gold_in']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('F'.$rowCount,$post['Gold_out']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('G'.$rowCount,$post['Gold_total']);
		    			$objPHPExcel->getActiveSheet()->setCellValue('H'.$rowCount,$post['Date']);
						$rowCount++;
					}
					/*print_r($post);
					echo "<br>";*/
    		}
    	}
    	/*	die;*/
    				header('Content-Type: application/vnd.ms-excel');	
					$filename="Cash_report";
					header('Content-Disposition: attachment;filename='.$filename.'.xls');
					header('Cache-Control: max-age=0');
					// If you're serving to IE 9, then the following may be needed
					header('Cache-Control: max-age=1');

					// If you're serving to IE over SSL, then the following may be needed
					// header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
					// header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
					header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
					// header ('Pragma: public'); // HTTP/1.0

					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$objWriter->save('php://output');
					// $objWriter->save($filename.'.xls');

					 // Yii::app()->end();
	    		// 	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	   			// 	header('Content-Disposition: attachment;filename="' . $save_name . '.xls"');
				   //  header('Cache-Control: max-age=0');

				   //  $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				   //  $objWriter->save('php://output');
    		/*echo "<pre>";
    		print_r($post_list);*/		
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Cashevent;

		// Uncomment the following line if AJAX validation is needed
		$this->performAjaxValidation($model);

		if(isset($_POST['Cashevent']))
		{
			$model->attributes=$_POST['Cashevent'];
		 
			if($_POST['Cashevent']['cash_type']==2)
			{
				$model->amount = "-".$_POST['Cashevent']['amount'];				
			}
			if($_POST['Cashevent']['gold_type']==2)
			{
				$model->gold_amount = "-".$_POST['Cashevent']['gold_amount'];				
			}
			$model->created_date = date('Y-m-d H:i:s');
			$model->user_id = Yii::app()->user->getId();

			// print_r($model->created_date);
			 // die;
			if($model->save())
			{
				Yii::app()->user->setFlash('success', 'Insert successfully');
				$this->redirect(array('view','id'=>$model->id));
			}
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);
		$model->amount=ltrim($model->amount, '-'); 

		$model->gold_amount=ltrim($model->gold_amount, '-'); 

		// Uncomment the following line if AJAX validation is needed
		 $this->performAjaxValidation($model);

		if(isset($_POST['Cashevent']))
		{
			$model->attributes=$_POST['Cashevent'];
		
			if($_POST['Cashevent']['cash_type']==2)
			{
				$model->amount = "-".$_POST['Cashevent']['amount'];				
			}

			if($_POST['Cashevent']['gold_type']==2)
			{
				$model->gold_amount = "-".$_POST['Cashevent']['gold_amount'];				
			}

			// $model->created_date = date('Y-m-d H:i:s');
			$model->user_id = Yii::app()->user->getId();

			if($model->save(false))
			{
				Yii::app()->user->setFlash('success', 'Updated successfully');
				$this->redirect(array('view','id'=>$model->id));
			}
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */

	public function actionDelete($id)
	{
		/*echo $id;
		die;*/
		$model = Cashevent::model()->findByPk($id);
			if($model)
			{
				  $model->is_deleted = 1;
				  $model->save(false);
			}
	}

	/*public function actionDelete($id)
	{
		$this->loadModel($id)->delete();
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}*/

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		// $dataProvider=new CActiveDataProvider('Cashevent');
		// $this->render('index',array(
		// 	'dataProvider'=>$dataProvider,
		// ));
		$this->actionAdmin();
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Cashevent('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Cashevent']))
			$model->attributes=$_GET['Cashevent'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Cashevent the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Cashevent::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Cashevent $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='cashevent-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}

<?php

/**
 * This is the model class for table "cp_cash_event".
 *
 * The followings are the available columns in table 'cp_cash_event':
 * @property integer $id
 * @property string $user_id
 * @property string $customer_id
 * @property integer $cash_type
 * @property string $amount
 * @property string $gold_type
 * @property string $gold_amount
 * @property string $created_date
 * @property integer $is_deleted
 */
class Cashevent extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cp_cash_event';
	}
	public $days;
	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('customer_id', 'required'),
			array('cash_type','chack_validation'),
			array('cash_type, is_deleted', 'numerical', 'integerOnly'=>true),
			array('user_id, customer_id, amount, gold_amount', 'length', 'max'=>255),
			array('amount,gold_amount','numerical'),
			array('gold_type', 'length', 'max'=>50),
			array('created_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, customer_id, cash_type, amount, gold_type, gold_amount, created_date, is_deleted', 'safe', 'on'=>'search'),
		);
	}

	public function chack_validation()
	{

		if(isset($_POST['Cashevent']['cash_type']) && $_POST['Cashevent']['cash_type'] != "" )
		{
			if(isset($_POST['Cashevent']['amount']) && $_POST['Cashevent']['amount'] == "" )
			{
     			$this->addError('amount','Cash amount cannot be blank');
     		}
		}

		if(isset($_POST['Cashevent']['gold_type']) && $_POST['Cashevent']['gold_type'] != "")
		{	
			if(isset($_POST['Cashevent']['gold_amount']) && $_POST['Cashevent']['gold_amount'] == "")
			{
				$this->addError('gold_amount', 'Gold amount cannot be blank');
			}
		}

		if(($_POST['Cashevent']['cash_type'] == "") && ($_POST['Cashevent']['gold_type'] == ""))
		{
			$this->addError('gold_amount', 'At least one cash event select');
		}

	}




	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(

			'getcust' => array(self::BELONGS_TO, 'Customer', 'customer_id'),


		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'customer_id' => 'Customer Name',
			'cash_type' => 'Cash Event',
			'amount' => 'Cash Amount',
			'gold_type' => 'Gold Event',
			'gold_amount' => 'Gold Amount',
			'created_date' => 'Created Date',
			'is_deleted' => 'Is Deleted',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->with = array('getcust');

		$criteria->compare('t.id',$this->id);
		if(isset($_GET['id']) && $_GET['id'])
			$criteria->compare('customer_id',$_GET['id']);
		else
			$criteria->compare('getcust.name',$this->customer_id,true);

		// $criteria->compare('customer_id',$this->customer_id,true);

		$criteria->compare('cash_type',$this->cash_type);
		$criteria->compare('amount',$this->amount,true);
		$criteria->compare('gold_type',$this->gold_type,true);
		$criteria->compare('gold_amount',$this->gold_amount,true);
		if(isset($this->created_date) && $this->created_date)
		{
		    $this->created_date=$this->created_date;
		    $date=date('Y-m-d',strtotime($this->created_date));
			$criteria->compare('t.created_date',$date,true);
		}
		
		$criteria->compare('t.is_deleted',0);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}


	public function search_event()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.
		if(isset($_GET['id']))
		{
		   $id=$_GET['id'];
		}
		$criteria=new CDbCriteria;
		$criteria->with = array('getcust');
		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.user_id',$this->user_id,true);
		// $criteria->compare('getcust.name',$this->customer_id,true);
		$criteria->compare('customer_id',$id);
		$criteria->compare('cash_type',$this->cash_type);
		$criteria->compare('amount',$this->amount,true);
		$criteria->compare('gold_type',$this->gold_type,true);
		$criteria->compare('gold_amount',$this->gold_amount,true);
		// $criteria->compare('t.created_date',$this->created_date,true);
		if(isset($this->created_date) && $this->created_date)
		{
		    $this->created_date=$this->created_date;
		    $date=date('Y-m-d',strtotime($this->created_date));
			$criteria->compare('t.created_date',$date,true);
		}
		$criteria->compare('t.is_deleted',0);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}


	public function cashTotal()
	{
		if(isset($_GET['id']))
		{
		   $id=$_GET['id'];
		}
		
		// $wages=Cashevent::model()->findAllByPk($id);
		$wages=Cashevent::model()->findAllByAttributes(array('customer_id'=>$id,'is_deleted'=>0));
		// print_r($wages);
		$days=0;
		foreach($wages as $wage)
		{
			$days+=$wage->amount;
			/*echo $days;
			echo "<br>";*/
		}
		return $days;

	}	

	public function goldTotal()
	{
		if(isset($_GET['id']))
		{
		   $id=$_GET['id'];
		}
		$wages=Cashevent::model()->findAllByAttributes(array('customer_id'=>$id,'is_deleted'=>0));
		$days=0;
		foreach($wages as $wage)
		{
			$days+=$wage->gold_amount;
		}

			return number_format((float)$days, 3, '.', '');
		// return $days;

	}	


	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Cashevent the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}

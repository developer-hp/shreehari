<div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1>Manage Cash</h1>
            </div>
        </div>
        <div class="col-sm-6 hidden-xs">
            <div class="header-section">
                <ul class="breadcrumb breadcrumb-top">
                    <li><?php echo CHtml::link('Manage Cash', array('admin')) ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <!-- Partial Responsive Block -->
        <div class="block">
            <!-- Partial Responsive Title -->
            <div class="block-title">
                <h2>Cash Listing </h2>
            </div>
            <!-- END Partial Responsive Title -->
            <?php if (Yii::app()->user->hasFlash('success')): ?>
                <div class="alert alert-success alert-dismissable">
                    <p><?php echo Yii::app()->user->getFlash('success'); ?></p>
                </div>
            <?php endif; ?>
            <?php // echo CHtml::button('Delete', array('id' => 'btnDelete', 'class' => 'btn btn-effect-ripple btn-danger')); ?>
            <?php echo CHtml::link('Add', array('create'), array('class' => 'btn btn-effect-ripple btn-info')); ?>

			<?php $this->widget('zii.widgets.grid.CGridView', array(
				'id'=>'cashevent-grid',
				'dataProvider'=>$model->search(),
				'filter'=>$model,
				'pager' => array(
                    'header' => '',
                    'selectedPageCssClass'=>'active',
                    // 'cssFile' => Yii::app()->baseurl . '/css/bootstrap.min.css',
                ),
				'itemsCssClass' => 'table table-striped table-bordered table-vcenter table-responsive',
				'columns'=>array(
					
					array(
		         		 'name'=>'customer_id',
		         		 'value'=>function($data){
		         		 	if(isset($data->getcust->name))
		         		 	{
		         		 		echo $data->getcust->name;
		         		 	}
		         		 }
	         		),
					
					
					array(
						'name'=>'referral_code',
						 'htmlOptions'=>array('style'=>'text-align: center;', 'class'=>'zzz'),
						'value'=>function($data)
						{
							echo $data->referral_code;
						}
					),

					array(
                        'name' => 'narration',
                        'type' => 'html',
                        'value' => function($data){
                            if (strlen($data->narration) > 30) {
                                return substr($data->narration, 0, 30).' ... ';
                            }else{
                                return $data->narration;
                            }
                        }
                    ),

					 array(
						'name'=>'created_date',
						'htmlOptions'=>array('style'=>'text-align: center;', 'class'=>'zzz'),
						'value'=>function($data)
						{
							echo $new_date = date('d-m-Y',strtotime($data->created_date));
							// echo $new_date = date('d-m-Y H:i:s',strtotime($data->created_date)); 
						}
					), 
					// 'created_date',
					// 'is_deleted',
					
					/*array(
						'class'=>'CButtonColumn',
					),*/
					array(
                        'class' => 'CButtonColumn',
                        'htmlOptions' => array('style' => 'width: 120px;text-align: center;'),
                        'template' => '{view} {update} {delete}',
                        'buttons' => array(
                            'update' => array(
                                'label' => '<i class="fa fa-pencil"></i>',
                                'imageUrl' => false,
                                'options' => array('class' => 'btn btn-effect-ripple btn-sm btn-success', 'rel' => 'tooltip', 'data-toggle' => 'tooltip', 'title' => Yii::t('app', 'Update')),
                                'type' => 'raw',
                            ),
                            'view' => array(
                                'label' => '<i class="fa fa-eye"></i>',
                                'imageUrl' => false,
                                'options' => array('class' => 'btn btn-effect-ripple btn-sm btn-warning', 'rel' => 'tooltip', 'data-toggle' => 'tooltip', 'title' => Yii::t('app', 'View Details')),
                                'type' => 'raw',
                                 'url'=>'Yii::app()->createUrl("cashevent/view_event",array("id"=>$data->id))'
                            ),
                            'delete' => array(
                            'options' => array('class' => 'btn btn-effect-ripple btn-sm btn-danger', 'rel' => 'tooltip', 'data-toggle' => 'tooltip', 'title' => Yii::t('app', 'Delete')),
                            'label' => '<i class="fa fa-trash"></i>',
                            'imageUrl' => false,
                        	),
                        ),
                    ),
				),
			)); ?>
	</div>
    </div>
</div>

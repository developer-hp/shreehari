<?php
/* @var $this CasheventController */
/* @var $model Cashevent */
/* @var $form CActiveForm */
?>

	<style type="text/css">
		.lable_amount{
			/*margin-left: 170px;*/
		}
	</style>

<?php $title="Event";?>

<div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1><?php echo $title;?></h1>
            </div>
        </div>
        <div class="col-sm-6 hidden-xs">
            <div class="header-section">
                <ul class="breadcrumb breadcrumb-top">
                    <?php 
                     $action=Yii::app()->controller->action->id;
                      if($action!='add'):?>
                        <li><?php                    
                           echo CHtml::link($title, array('admin'));
                          ?></li>
                    <?php endif;?>
                    <li><?php echo $model->isNewRecord ? Yii::t('yii','Create') : Yii::t('yii','Edit'); ?></li>
                    <input type="hidden" class="test" value="<?php echo $model->isNewRecord ? 'Create' : 'Edit'; ?>">
                </ul>
            </div>
        </div>
    </div>
</div>
<?php
// echo "<pre>";
	// print_r($cash_log_model);
?>

<div class="row">
    <div class="col-md-12">
     <!-- Horizontal Form Block -->
        <div class="block">
            
            <!-- Horizontal Form Title -->
            <div class="block-title">
                <h2><?php echo $model->isNewRecord ? Yii::t('yii','Create') : Yii::t('yii','Edit'); ?> <?php echo $title;?></h2>
            </div>

              <?php if (Yii::app()->user->hasFlash('success')): ?>
                <div class="alert alert-success alert-dismissable">
                    <p><?php echo Yii::app()->user->getFlash('success'); ?></p>
                </div>
                <?php endif; ?> 

					<?php $form=$this->beginWidget('CActiveForm', array(
						'id'=>'cashevent-form',
						'enableAjaxValidation' => true,
						    'htmlOptions' => array('class' => 'form-horizontal form-bordered', 'enctype' => 'multipart/form-data'),
						    'clientOptions' => array(
						        'validateOnSubmit' => true,
						    ),
						    'errorMessageCssClass' => 'help-block animation-slideUp form-error',
						// Please note: When you enable ajax validation, make sure the corresponding
						// controller action is handling ajax validation correctly.
						// There is a call to performAjaxValidation() commented in generated controller code.
						// See class documentation of CActiveForm for details on this.
						// 'enableAjaxValidation'=>false,
					)); ?>

						<!-- <p class="note">Fields with <span class="required">*</span> are required.</p> -->

						<?php // echo $form->errorSummary($model); ?>


						<div class="form-group">
							<div class="col-md-12">
							<?php echo $form->labelEx($model,'customer_id', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-6">
							<?php // echo $form->textField($model,'customer_id', array('class' => 'form-control')); 
								// $customer = Customer::model()->findAll();
								// print_r($customer);
								echo $form->dropDownList($model,'customer_id',CHtml::listData(Customer::model()->findAll(array("condition"=>"is_deleted = 0")),'id','name'),
									array(
										'prompt'=>'----Select Customer----',
										'class'=>'form-control',
									)); 
							?>
							<?php echo $form->error($model,'customer_id'); ?>
							</div>
						</div>
					</div>

			            <?php
			            	if($model->isNewRecord)
			            	{
			            ?>
				            <div class="form-group blocks">
				            	<div class="col-md-12">
				            		<label class="col-md-2 control-label"></label>
				            		<div class="col-md-3">
				            			<label>Item</label>
				            			<?php //  echo $form->textField($cash_log,'note[]', array('class' => 'form-control','placeholder'=>"Enter Item Name")); ?>
				            			<?php // echo $form->error($cash_log,'note'); ?>
				            			<input type="text" placeholder="Enter Item Name" name="note[]" id="item" class="form-control nameclass">
				            		</div>
				            		<div class="col-md-3">
				            			<label>Amount</label>
				            			<?php // echo $form->textField($cash_log,'amount[]', array('class' => 'form-control','placeholder'=>"Enter Amount")); ?>
				            			<?php //  echo $form->error($cash_log,'amount'); ?>
				            			<input type="text" placeholder="Enter Amount" name="amount[]" id="amount" class="form-control nameclass numeric_amount">
				            		</div>
				            		<div class="col-md-1" style="margin-top: 25px;">
				                            <a class="btn btn-primary add_button"><i class="gi gi-plus"></i></a>
				                    </div>
				            	</div>
							<div class="items"></div>
				            </div>

			            <?php
			        	}
			        	else
			        	{
			        		?>
			        		 <div class="form-group">
			        		 	<label style="margin-left: 210px;">Item</label>
			        		 	<label style="margin-left: 225px;">Amount</label>


			        		<?php
			        			if(empty($cash_log_model))
			        			{
			        				?>

			        				<div class="col-md-12" style="margin-top:10px;">
				            		<label class="col-md-2 control-label"></label>
				            		<div class="col-md-3">
				            			<!-- <label>Item</label> -->
				            			<input type="text" placeholder="Enter Item Name" name="note[]" id="item" class="form-control nameclass" value="">
				            		</div>
				            		<div class="col-md-3">
				            			<!-- <label>Amount</label> -->
				            			<input type="text" placeholder="Enter Amount" name="amount[]" id="amount" class="form-control nameclass numeric_amount" value="">
				            		</div>
				            		<div class="col-md-1">
				                        <a class="btn btn-primary add_button"><i class="gi gi-plus"></i></a>
				                    </div>
				                    <div class="col-md-1">
						            	<!-- <a class="btn btn-danger remove"><i class="fa fa-times"></i></a> -->
						        	</div>
			        		</div>
			        				<?php
			        			}

			        		foreach ($cash_log_model as $key => $value)
			        		{

			        			$new_amount=ltrim($value->amount,'-'); 	
			        		?>
				            	<div class="col-md-12" style="margin-top:10px;">
				            		<label class="col-md-2 control-label"></label>
				            		<div class="col-md-3">
				            			<!-- <label>Item</label> -->
				            			<input type="text" placeholder="Enter Item Name" name="note[]" id="item" class="form-control nameclass" value="<?php echo $value->note; ?>">
				            		</div>
				            		<div class="col-md-3">
				            			<!-- <label>Amount</label> -->
				            			<input type="text" placeholder="Enter Amount" name="amount[]" id="amount" class="form-control nameclass numeric_amount" value="<?php echo $new_amount; ?>">
				            		</div>
				            		<div class="col-md-1">
				                        <a class="btn btn-primary add_button"><i class="gi gi-plus"></i></a>
				                    </div>
				                    <div class="col-md-1">
						            	<a class="btn btn-danger delete_record" data-id="<?php echo $value->id;?>"><i class="fa fa-times"></i></a>
						        	</div>
			        		</div>
			        		<?php
			        		}
			        		?>
							<div class="items"></div>
				            </div>
				        <?php
			        	}	
			            ?>

						<div class="form-group">
							<div class="col-md-12">
								<?php echo $form->labelEx($model,'cash_type', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
								$cash_type=array(1=>'IN',2=>'OUT');
								echo $form->dropDownList($model,'cash_type',$cash_type,
										array(
											'prompt'=>'----Select Cash Event----',
											'class'=>'form-control',
										)); 
								?>
								<?php echo $form->error($model,'cash_type'); ?>
								</div>

								<?php // echo $form->labelEx($model,'amount', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php echo $form->textField($model,'amount', array('class' => 'form-control','maxlength'=>13 ,'placeholder'=>"Enter Cash Amount")); ?>
								<?php echo $form->error($model,'amount'); ?>
							
								</div>
							</div>
						</div>



						<div class="form-group">
							<div class="col-md-12">
								<?php echo $form->labelEx($model,'gold_type', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
								$gold_type=array(1=>'IN',2=>'OUT');
								echo $form->dropDownList($model,'gold_type',$gold_type,
										array(
											'prompt'=>'----Select Gold Event----',
											'class'=>'form-control',
										)); 
								?>
								<?php echo $form->error($model,'gold_type'); ?>
								</div>

								<?php // echo $form->labelEx($model,'amount', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php echo $form->textField($model,'gold_amount', array('class' => 'form-control','maxlength'=>13 ,'placeholder'=>"Enter Gold Amount")); ?>
								<?php echo $form->error($model,'gold_amount'); ?>
							
								</div>
							</div>
						</div>


						<div class="form-group">
							<div class="col-md-12">
								<?php echo $form->labelEx($model,'bank_type', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
								$bank_type=array(1=>'IN',2=>'OUT');
								echo $form->dropDownList($model,'bank_type',$bank_type,
										array(
											'prompt'=>'----Select Bank Event----',
											'class'=>'form-control',
										)); 
								?>
								<?php echo $form->error($model,'bank_type'); ?>
								</div>

								<?php // echo $form->labelEx($model,'amount', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php echo $form->textField($model,'bank_amount', array('class' => 'form-control','maxlength'=>13 ,'placeholder'=>"Enter Bank Amount")); ?>
								<?php echo $form->error($model,'bank_amount'); ?>
							
								</div>
							</div>
						</div>

						<div class="form-group">
							<div class="col-md-12">
								<?php echo $form->labelEx($model,'card_type', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
								$card_type=array(1=>'IN',2=>'OUT');
								echo $form->dropDownList($model,'card_type',$card_type,
										array(
											'prompt'=>'----Select Card Event----',
											'class'=>'form-control',
										)); 
								?>
								<?php echo $form->error($model,'card_type'); ?>
									
								</div>

								<?php // echo $form->labelEx($model,'amount', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php echo $form->textField($model,'card_amount', array('class' => 'form-control','maxlength'=>13 ,'placeholder'=>"Enter Card Amount")); ?>
						
									<?php echo $form->error($model,'card_amount'); ?>
								</div>
							</div>
						</div>


						<div class="form-group">
							<div class="col-md-12">
								<?php echo $form->labelEx($model,'discount_type', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php // echo $form->textArea($model,'type', array('class' => 'form-control')); 
								$discount_type=array(1=>'IN',2=>'OUT');
								echo $form->dropDownList($model,'discount_type',$discount_type,
										array(
											'prompt'=>'----Select Discount Event----',
											'class'=>'form-control',
										)); 
								?>
								<?php echo $form->error($model,'discount_type'); ?>
								<?php // echo $form->error($model,'discount_amount'); ?>
								</div>

								<?php // echo $form->labelEx($model,'amount', array('class' => 'col-md-2 control-label')); ?>
								<div class="col-md-3">
								<?php echo $form->textField($model,'discount_amount', array('class' => 'form-control','maxlength'=>13 ,'placeholder'=>"Enter Discount Amount")); ?>
									<?php echo $form->error($model,'discount_amount'); ?>
							
							
								</div>
							</div>
						</div>


						<div class="form-group">
							<div class="col-md-12">
							<?php echo $form->labelEx($model,'narration', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-6">
							<?php  echo $form->textArea($model,'narration', array('class' => 'form-control')); 
								// $customer = Customer::model()->findAll();
								// print_r($customer);
							?>
							<?php echo $form->error($model,'narration'); ?>
							</div>
						</div>
					</div>

					<div class="form-group">
							<div class="col-md-12">
							<?php echo $form->labelEx($model,'created_date', array('class' => 'col-md-2 control-label')); ?>
							<div class="col-md-3">
							<?php  echo $form->textField($model,'created_date', array('class' => 'form-control input-datepicker','data-date-format'=>"dd-mm-yyyy",'readonly'=>"readonly" ,'autocomplete'=>'off')); 
								// $customer = Customer::model()->findAll();
								// print_r($customer);
							?>
							<?php echo $form->error($model,'created_date'); ?>
							</div>
						</div>
					</div>

					<div class="form-group form-actions">
				        <div class="col-md-9 col-md-offset-3">
				            <?php echo CHtml::submitButton($model->isNewRecord ? Yii::t('yii','Save') : Yii::t('yii','Save'), array('class' => 'btn btn-effect-ripple btn-primary submit')); ?>
				            <?php echo CHtml::link(Yii::t('yii','Cancel'), array('admin'), array('class' => 'btn btn-effect-ripple btn-danger')) ?>
				        </div>
				    </div>
				<?php $this->endWidget(); ?>
			</div>
	</div>
</div>

 					<div class="form-group hidden add-more">
 						 <!-- <div class="blocks row">  -->
			            	<div class="blocks col-md-12" style="margin-top: 10px;">
			            		<label class="col-md-2 control-label"></label>
			            		<div class="col-md-3">
			            			<?php // echo $form->textField($cash_log,'note[]', array('class' => 'form-control','placeholder'=>"Enter Item Name")); ?>
			            			<?php // echo $form->error($cash_log,'note'); ?>
			            			<input type="text" placeholder="Enter Item Name" name="note[]" id="item" class="form-control nameclass">
			            		</div>
			            		<div class="col-md-3">
			            			<?php // echo $form->textField($cash_log,'amount[]', array('class' => 'form-control','placeholder'=>"Enter Amount")); ?>
			            			<?php // echo $form->error($cash_log,'amount'); ?>
			            			<input type="text" placeholder="Enter Amount" name="amount[]" id="amount" class="form-control nameclass numeric_amount">
			            		</div>
			            		<div class="col-md-1">
			                            <a class="btn btn-primary add_button"><i class="gi gi-plus"></i></a>
			                    </div>
			                     <div class="col-md-1">
						            <a class="btn btn-danger remove"><i class="fa fa-times"></i></a>
						        </div>
			            	</div>
			        </div>

			            <!-- </div> -->

<!-- 
<div class="hidden add-more">
    <div class="blocks row">        
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="col-sm-4 form-group">
                  <input type="text" name="account_name[]" placeholder="Account name" id="Account name" class="form-control nameclass">
            </div>
            <div class="col-sm-3 form-group">
                <input type="text" name="account_number[]" placeholder="Account number" id="Account number" class="form-control nameclass">
            </div>
             <div class="col-md-1 form-group">
                    <a class="btn btn-primary add_button"><i class="gi gi-plus"></i></a>
            </div>   
             <div class="col-md-1 form-group">
	            <a class="btn btn-danger remove"><i class="fa fa-times"></i></a>
	        </div>
        </div>  
    </div>
</div> -->



<script type="text/javascript">
       $(document).ready(function()
  	   {
        var numchk = new RegExp("^[0-9]*$");     

        $('body').on('change','.numeric_amount',function()
        {
        	if( numchk.test( $(this).val() ) )
        	{
                // console.log("Numeric value");
            }
            else
            {
        		$(this).after('<span class="text-danger errormsg errorMessage  help-block animation-slideUp form-error">'+$(this).attr('id')+' numeric only.</span>');
                // return false;
           		// console.log("Value not numeric");
            }
        });       
    });
</script>
  <script type="text/javascript">

  	   $(document).ready(function()
  	   {

  	   // $(".numeric_amount").bind("keypress", function (e) {
      //     var keyCode = e.which ? e.which : e.keyCode
               
      //     if (!(keyCode >= 48 && keyCode <= 57)) {
      //       $(".error").css("display", "inline");
      //       return false;
      //     }else{
      //       $(".error").css("display", "none");
      //     }
      // });


	  	 $('body').on('click','.add_button',function(){

	            var h = $('.add-more').html().replace('item-ele','item');
	            $('.items').append(h);
	        });

	  	  $('body').on('click','.remove',function(){
            $(this).closest('.blocks').remove();
        	});


	  	  $("#cashevent-form").submit(function(event) {            
            var valid = true;
            $('.errormsg').remove();
            $("#cashevent-form .nameclass").each(function() {
                if( ! $(this).val() ){
                    $(this).after('<span class="text-danger errormsg errorMessage  help-block animation-slideUp form-error">'+$(this).attr('id')+' cannot be blank.</span>');
                    valid = false;
                }
            });
            
            if (!valid){
                return false;
            }else{
                    return true;
                 }
            event.preventDefault();

        });




	  	 });


  	    $('body').on('click','.delete_record',function()
       {
            var delete_id = $(this).attr("data-id");
             var $row = $(this).parent().parent();
             // alert(delete_id);
            if (confirm('Are you sure you want to delete this?')) 
            {
            if(delete_id!= "")
            {
               $.ajax({
                  type: "POST",
                  url: '<?php  echo Yii::app()->createUrl("cashevent/remove_record");?>',
                  data: {'delete_id':delete_id},
                  cache: false,
                  success: function(data)
                  {
                    if(data == 1)
                    {
                          $row.remove();
                        // $(this).closest('.blocks').remove();
                    }
                  }
            	});
       		 }
            }
       });
            
            $('body').on('keydown', 'input, select', function(e) {
                if (e.key === "Enter") {
                    var self = $(this), form = self.parents('form:eq(0)'), focusable, next;
                    focusable = form.find('input,a,select,button,textarea').filter(':visible');
                    next = focusable.eq(focusable.index(this)+1);
                    if (next.length) {
                        next.focus();
                    } else {
                        form.submit();
                    }
                    return false;
                }
            });






        </script>


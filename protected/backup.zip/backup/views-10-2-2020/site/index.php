<!--  <div class="content-header">
    <div class="row">
        <div class="col-sm-6">
            <div class="header-section">
                <h1>Home</h1>
            </div>
        </div>
        
    </div>
</div> -->


<div class="row">
    <div class="col-sm-6 col-lg-4">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-money text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong><span data-toggle="counter" data-to="2862">
                             <?php
                                    
                                
                                    /* $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and cash_type=1');
                                    $total_cash_in = "";
                                    foreach ($model as $key => $value)
                                    {
                                        $total_cash_in = $total_cash_in+$value->amount;
                                      
                                    }
                                     echo $total_cash_in; */

                                      $date = date("Y-m-d");
                                      $deleted = 0;
// SELECT sum(amount) as amount FROM cp_cash_logs WHERE 1=1 and type ="1" and date BETWEEN "2020-02-08 00:00:00" AND "2020-02-08 23:59:59"
                                      $condition = "1=1";
                                      $criteria=new CDbCriteria;
                                      $criteria->select=' sum(amount) as amount';
                                      $condition .= ' AND type ="1" ';
                                      $condition .= ' AND date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                                      $criteria->condition = $condition;
                                      // print_r($criteria);die();
                                      $cash_amount=Cashlogs::model()->find($criteria);
                                      echo "₹ ".$cash_amount->amount;

                                    ?>
                    </span></strong>
                </h2>
                <span class="text-muted">Today Cash Amount</span>
            </div>
        </a>
    </div>

    <div class="col-sm-6 col-lg-4">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-money text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong> <span data-toggle="counter" data-to="2862">
                          <?php
                           /* $date = date("Y-m-d");
                         
                            $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and cash_type=2');
                            $total_cash_out = "";
                            foreach ($model as $key => $value)
                            {
                                $cash_amount = ltrim($value->amount, '-'); 
                                $total_cash_out = $total_cash_out+$cash_amount;
                            }
                           echo $total_cash_out;*/

                           // $deleted = 0;
                           //            $condition = "1=1";
                           //            $criteria=new CDbCriteria;
                           //            $criteria->select=' * ,sum(amount) as amount';
                           //            $condition .= ' and is_deleted ="'. $deleted.'" and cash_type ="2"  ';
                           //            $condition .= ' and created_date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                           //            $criteria->condition = $condition;
                           //            $model_out=Cashevent::model()->find($criteria);
                           //             $cash_amount_out = ltrim($model_out->amount, '-'); 
                           //            echo "₹ ".$cash_amount_out;
                                  $condition = "1=1";
                                      $criteria=new CDbCriteria;
                                      $criteria->select=' sum(amount) as amount';
                                      $condition .= ' AND type ="2" ';
                                      $condition .= ' AND date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                                      $criteria->condition = $condition;
                                      // print_r($criteria);die();
                                      $model_gold=Cashlogs::model()->find($criteria);
                                      echo "₹ ".$model_gold->amount;

                        ?>

                    </span></strong>
                </h2>
                <span class="text-muted">Today Gold Amount</span>
            </div>
        </a>
    </div>
    <div class="col-sm-6 col-lg-4">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-money text-light-op"></i>
                    <!-- <i class="fas fa-coins"></i> -->
                </div>
                <h2 class="widget-heading h3 text">
                    <strong> <span data-toggle="counter" data-to="2862">
                        
                    <?php
                      /*  $date = date("Y-m-d");
                        $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and gold_type=1');
                        $total_gold_in = "";
                        foreach ($model as $key => $value)
                        {
                            $total_gold_in = $total_gold_in+$value->gold_amount;
                          
                        }
                         echo $total_gold_in; */

                                 $condition = "1=1";
                                      $criteria=new CDbCriteria;
                                      $criteria->select=' sum(amount) as amount';
                                      $condition .= ' AND type ="3" ';
                                      $condition .= ' AND date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                                      $criteria->condition = $condition;
                                      // print_r($criteria);die();
                                      $model_bank=Cashlogs::model()->find($criteria);
                                      echo "₹ ".$model_bank->amount;

                    ?>

                    </span></strong>
                </h2>
                <span class="text-muted">Today Bank Amount</span>
            </div>
        </a>
    </div>
    <div class="col-sm-6 col-lg-4" >
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-money text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong><span data-toggle="counter" data-to="2862">
                        
                         <?php
                          /*  $date = date("Y-m-d");
                            $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and gold_type=2');
                            $total_gold_out = "";
                            foreach ($model as $key => $value)
                            {
                                $gold_amount_change = ltrim($value->gold_amount, '-'); 
                                $total_gold_out = $total_gold_out+$gold_amount_change;
                            }
                           echo $total_gold_out; */

                                   $condition = "1=1";
                                      $criteria=new CDbCriteria;
                                      $criteria->select=' sum(amount) as amount';
                                      $condition .= ' AND type ="4" ';
                                      $condition .= ' AND date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                                      $criteria->condition = $condition;
                                      // print_r($criteria);die();
                                      $model_card=Cashlogs::model()->find($criteria);
                                      echo "₹ ".$model_card->amount;


                        ?>


                    </span></strong>
                </h2>
                <span class="text-muted">Today Card Amount</span>
            </div>
        </a>
    </div>


    <div class="col-sm-6 col-lg-4">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-money text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong><span data-toggle="counter" data-to="2862">
                             <?php
                                   
                                    /* $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and cash_type=1');
                                    $total_cash_in = "";
                                    foreach ($model as $key => $value)
                                    {
                                        $total_cash_in = $total_cash_in+$value->amount;
                                      
                                    }
                                     echo $total_cash_in; */

                                      $condition = "1=1";
                                      $criteria=new CDbCriteria;
                                      $criteria->select=' sum(amount) as amount';
                                      $condition .= ' AND type ="5" ';
                                      $condition .= ' AND date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                                      $criteria->condition = $condition;
                                      // print_r($criteria);die();
                                      $model_card=Cashlogs::model()->find($criteria);
                                      echo "₹ ".$model_card->amount;

                                    ?>
                    </span></strong>
                </h2>
                <span class="text-muted">Today Discount Amount</span>
            </div>
        </a>
    </div>


     <div class="col-sm-6 col-lg-4">
        <a href="javascript:void(0)" class="widget">
            <div class="widget-content widget-content-mini text-right clearfix">
                <div class="widget-icon pull-left themed-background">
                    <i class="fa fa-money text-light-op"></i>
                </div>
                <h2 class="widget-heading h3 text">
                    <strong> <span data-toggle="counter" data-to="2862">
                          <?php
                           /* $date = date("Y-m-d");
                         
                            $model = Cashevent::model()->findAll('DATE(created_date) ="'. $date.'" and is_deleted=0 and cash_type=2');
                            $total_cash_out = "";
                            foreach ($model as $key => $value)
                            {
                                $cash_amount = ltrim($value->amount, '-'); 
                                $total_cash_out = $total_cash_out+$cash_amount;
                            }
                           echo $total_cash_out;*/

                                     $condition = "1=1";
                                      $criteria=new CDbCriteria;
                                      $criteria->select=' sum(amount) as amount';
                                      $condition .= ' AND type ="6" ';
                                      $condition .= ' AND date BETWEEN "'.$date.' 00:00:00" AND "'.$date.' 23:59:59 "';
                                      $criteria->condition = $condition;
                                      // print_r($criteria);die();
                                      $model_dis=Cashlogs::model()->find($criteria);
                                      echo "₹ ".$model_dis->amount;
                        ?>

                    </span></strong>
                </h2>
                <span class="text-muted">Today Item Amount</span>
            </div>
        </a>
    </div>

    
    
                 
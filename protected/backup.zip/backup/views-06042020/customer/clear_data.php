<div class="row">
    <div class="col-md-12">
     <!-- Horizontal Form Block -->
        <div class="">
    	
        	  <form name="clear" method="post" action="<?php echo Yii::app()->createUrl('customer/database_export');?>" >
        	  	<div class="form-group">
    	  				<label class="col-md-4 control-label" style="margin-right: -50px;">Enter Password::</label>
							<div class="col-md-7">
								<input type="Password" name="user_password" class="form-control">
							</div>
						</div>

						<div class="form-group form-actions" >
				        <div class="col-md-9 col-md-offset-3" style="margin-top: 20px !important;">
				        	<input type="submit" name="submit" value="Clear Data" class="btn btn-effect-ripple btn-primary">
				            <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-left: 5px;">Close</button>           
				        </div>
				    </div>
		       <!-- <button type="submit" name="clear_all_data" class="btn btn-danger clear_all_data" onclick="return confirm('Are sure clear all data in database..?');"><i class="fa fa-trash"> Clear Data</i></button> -->
		      </form>

     	</div>
 	</div>
</div>
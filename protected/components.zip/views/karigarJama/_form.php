<?php
$form = $this->beginWidget('CActiveForm', array(
    'id' => 'karigar-jama-form',
    'enableAjaxValidation' => true,
    'errorMessageCssClass' => 'help-block animation-slideUp form-error',
    'htmlOptions' => array('class' => 'form-horizontal'),
));
$voucherDate = $model->voucher_date;
if (!empty($voucherDate) && preg_match('/^\d{4}-\d{2}-\d{2}/', $voucherDate)) $voucherDate = date('d-m-Y', strtotime($voucherDate));
if (!$voucherDate) $voucherDate = date('d-m-Y');

$voucherDisplay = (string) $model->voucher_number;
if ($voucherDisplay === '') {
    if ($model->isNewRecord) {
        try {
            $voucherDisplay = DocumentNumberService::peekNextSrNo(DocumentNumberService::DOC_KARIGAR_JAMA_VOUCHER);
        } catch (Exception $e) {
            $voucherDisplay = 'AUTO';
        }
    } else {
        $voucherDisplay = 'AUTO';
    }
}

$lines = $model->isNewRecord ? array(array()) : $model->lines;
if (empty($lines)) $lines = array(array());
$caratOptions = KarigarJamaVoucherLine::getCaratOptions();
$drcrOptions = IssueEntry::getDrcrOptions();
?>
<?php echo $form->hiddenField($model, 'drcr', array('value' => IssueEntry::DRCR_CREDIT)); ?>
<div class="form-group">
    <?php echo $form->labelEx($model, 'voucher_date', array('class' => 'col-sm-2 control-label')); ?>
    <div class="col-sm-4">
        <?php echo $form->textField($model, 'voucher_date', array('class' => 'form-control input-datepicker', 'data-date-format' => 'dd-mm-yyyy', 'value' => $voucherDate, 'placeholder' => 'dd-mm-yyyy', 'autocomplete' => 'off')); ?>
        <?php echo $form->error($model, 'voucher_date'); ?>
    </div>
</div>
<?php if ($model->isNewRecord): ?>
<div class="form-group">
    <label class="col-sm-2 control-label">Voucher No</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" value="<?php echo CHtml::encode($voucherDisplay); ?>" readonly="readonly" style="background:#f7f7f7;" />
    </div>
</div>
<?php endif; ?>
<div class="form-group">
    <?php echo $form->labelEx($model, 'karigar_id', array('class' => 'col-sm-2 control-label')); ?>
    <div class="col-sm-4">
        <?php
        $karigars = CHtml::listData(Customer::model()->findAll(array('condition' => 'is_deleted = 0 AND type = 3', 'order' => 'name')), 'id', 'name');
        echo $form->dropDownList($model, 'karigar_id', $karigars, array('class' => 'form-control select2-karigar', 'prompt' => '----Select Karigar----'));
        ?>
        <?php echo $form->error($model, 'karigar_id'); ?>
    </div>
</div>
<?php if (!$model->isNewRecord): ?>
<div class="form-group">
    <?php echo $form->labelEx($model, 'sr_no', array('class' => 'col-sm-2 control-label')); ?>
    <div class="col-sm-4">
        <?php echo $form->textField($model, 'sr_no', array('class' => 'form-control')); ?>
        <?php echo $form->error($model, 'sr_no'); ?>
    </div>
</div>
<?php endif; ?>
<div class="form-group">
    <?php echo $form->labelEx($model, 'remark', array('class' => 'col-sm-2 control-label')); ?>
    <div class="col-sm-8">
        <?php echo $form->textArea($model, 'remark', array('class' => 'form-control', 'rows' => 3, 'placeholder' => 'Enter remarks...')); ?>
        <?php echo $form->error($model, 'remark'); ?>
    </div>
</div>

<h4>Items</h4>
<div id="lines-container">
<?php foreach ($lines as $idx => $line): ?>
<?php
$ln = is_object($line) ? $line : array();
$stones = is_object($line) && isset($line->stones) ? $line->stones : array(array());
if (empty($stones)) $stones = array(array());
?>
<div class="line-block panel panel-default" data-idx="<?php echo $idx; ?>">
    <div class="panel-body">
        <div class="row margin-bottom-5">
            <div class="col-sm-1"><strong>Sr</strong></div>
            <div class="col-sm-1"><strong>Order No</strong></div>
            <div class="col-sm-1"><strong>Customer</strong></div>
            <div class="col-sm-1"><strong>Item</strong></div>
            <div class="col-sm-1"><strong>Carat</strong></div>
            <div class="col-sm-1"><strong>Psc</strong></div>
            <div class="col-sm-1"><strong>Gross</strong></div>
            <div class="col-sm-1"><strong>Net</strong></div>
            <div class="col-sm-1"><strong>Touch%</strong></div>
            <div class="col-sm-1"><strong>Wst</strong></div>
            <div class="col-sm-1"><strong>Remark</strong></div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row form-group">
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][sr_no]", is_object($ln) ? (isset($ln->sr_no) ? $ln->sr_no : '') : (isset($ln['sr_no']) ? $ln['sr_no'] : ''), array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Sr')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][order_no]", is_object($ln)?$ln->order_no:'', array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Order No')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][customer_name]", is_object($ln)?$ln->customer_name:'', array('class' => 'form-control input-sm', 'placeholder' => 'Customer')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][item_name]", is_object($ln)?$ln->item_name:'', array('class' => 'form-control input-sm', 'placeholder' => 'Item')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::dropDownList("lines[{$idx}][carat]", is_object($ln) ? (isset($ln->carat) ? $ln->carat : '') : (isset($ln['carat']) ? $ln['carat'] : ''), $caratOptions, array('class' => 'form-control input-sm', 'prompt' => 'Carat')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][psc]", is_object($ln)?$ln->psc:'', array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Psc')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][gross_wt]", is_object($ln)?$ln->gross_wt:'', array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Gross')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][net_wt]", is_object($ln)?$ln->net_wt:'', array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Net')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][touch_pct]", is_object($ln)?$ln->touch_pct:'', array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Touch%')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][wastage]", is_object($ln) ? ((isset($ln->wastage) && $ln->wastage !== null && $ln->wastage !== '') ? $ln->wastage : 0) : (isset($ln['wastage']) && $ln['wastage'] !== '' ? $ln['wastage'] : 0), array('class' => 'form-control input-sm kj-numeric', 'placeholder' => 'Wst')); ?></div>
            <div class="col-sm-1"><?php echo CHtml::textField("lines[{$idx}][remark]", is_object($ln)?$ln->remark:'', array('class' => 'form-control input-sm', 'placeholder' => 'Remark')); ?></div>
            <div class="col-sm-1"><button type="button" class="btn btn-danger btn-sm btn-remove-line">Remove</button></div>
        </div>
        <div class="small mt-2">
            <div class="row margin-bottom-5">
                <div class="col-sm-2"><strong>Stone/Diamond/Other:</strong></div>
                <div class="col-sm-2"><strong>Item</strong></div>
                <div class="col-sm-2"><strong>Weight</strong></div>
                <div class="col-sm-2"><strong>Amount</strong></div>
                <div class="col-sm-2"><button type="button" class="btn btn-xs btn-primary btn-add-stone">+ Add stone</button></div>
            </div>
            <div class="stone-rows" data-line-idx="<?php echo $idx; ?>">
            <?php foreach ($stones as $sj => $st): ?>
            <?php
            $sItem = is_object($st) ? (isset($st->item) ? $st->item : '') : (isset($st['item']) ? $st['item'] : '');
            $sWt   = is_object($st) ? (isset($st->stone_wt) ? $st->stone_wt : '') : (isset($st['stone_wt']) ? $st['stone_wt'] : '');
            $sAmt  = is_object($st) ? (isset($st->stone_amount) ? $st->stone_amount : '') : (isset($st['stone_amount']) ? $st['stone_amount'] : '');
            ?>
            <div class="row stone-row margin-bottom-5">
                <div class="col-sm-2"></div>
                <div class="col-sm-2"><?php echo CHtml::textField("lines[{$idx}][stones][{$sj}][item]", $sItem, array('class'=>'form-control input-sm','placeholder'=>'Item')); ?></div>
                <div class="col-sm-2"><?php echo CHtml::textField("lines[{$idx}][stones][{$sj}][stone_wt]", $sWt, array('class'=>'form-control input-sm kj-numeric','placeholder'=>'Wt')); ?></div>
                <div class="col-sm-2"><?php echo CHtml::textField("lines[{$idx}][stones][{$sj}][stone_amount]", $sAmt, array('class'=>'form-control input-sm kj-numeric','placeholder'=>'Amt')); ?></div>
                <div class="col-sm-2"><button type="button" class="btn btn-xs btn-danger btn-remove-stone">Remove</button></div>
            </div>
            <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
</div>
<p><button type="button" id="add-line-btn" class="btn btn-default">Add Item</button></p>

<div class="panel panel-default margin-top-15">
    <div class="panel-body">
        <strong>Total Fine Wt:</strong> <span id="jama-total-fine-wt">0.000</span> &nbsp;&nbsp;|&nbsp;&nbsp; <strong>Total Amount:</strong> <span id="jama-total-amount">0.00</span>
    </div>
</div>

<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
        <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save', array('class' => 'btn btn-primary')); ?>
        <?php echo CHtml::submitButton('Save & Print', array('class' => 'btn btn-info', 'name' => 'save_print')); ?>
        <?php echo CHtml::link('Cancel', array('karigarJama/admin'), array('class' => 'btn btn-default')); ?>
    </div>
</div>
<?php $this->endWidget(); ?>

<script type="text/javascript">
$(function() {
    var formSelector = '#karigar-jama-form';

    function focusNextField($current, reverse) {
        var $fields = $(formSelector).find('input, select, textarea, button, a').filter(':visible:enabled').filter(function() {
            var $el = $(this);
            if ($el.is('[tabindex="-1"]')) return false;
            if ($el.is('[readonly]') || $el.is(':disabled')) return false;
            return true;
        });
        var index = $fields.index($current);
        if (index < 0) return;
        var nextIndex = reverse ? index - 1 : index + 1;
        if (nextIndex < 0 || nextIndex >= $fields.length) return;
        $fields.eq(nextIndex).focus();
    }

    $(document).on('keydown', formSelector + ' input, ' + formSelector + ' select, ' + formSelector + ' textarea', function(ev) {
        if ((ev.which || ev.keyCode) !== 13) return;
        if ($(ev.target).is('textarea')) return;
        ev.preventDefault();
        focusNextField($(this), ev.shiftKey);
    });

    var $karigarSelect = $('.select2-karigar');
    if ($karigarSelect.length && (!$karigarSelect.data('select2'))) {
        $karigarSelect.select2({ placeholder: '----Select Karigar----', allowClear: true, width: '100%' });
    }

    function sanitizeNumericInput(el) {
        var v = el.value;
        var start = el.selectionStart, end = el.selectionEnd;
        v = v.replace(/[^0-9.\-]/g, '');
        var firstMinus = v.indexOf('-');
        if (firstMinus > 0) v = v.replace(/-/g, '');
        else if (firstMinus === 0 && v.indexOf('-', 1) >= 0) v = v.substring(0, 1) + v.substring(1).replace(/-/g, '');
        var dotCount = (v.match(/\./g) || []).length;
        if (dotCount > 1) {
            var idx = v.indexOf('.');
            v = v.substring(0, idx + 1) + v.substring(idx + 1).replace(/\./g, '');
        }
        el.value = v;
        el.setSelectionRange(Math.min(start, v.length), Math.min(end, v.length));
    }
    $(document).on('keypress', '#karigar-jama-form .kj-numeric', function(ev) {
        var k = ev.which || ev.keyCode;
        if (k <= 0 || ev.ctrlKey || ev.metaKey || ev.altKey) return;
        if (k === 8 || k === 9 || k === 46) return;
        if (k === 45) { if (this.value.length > 0 || this.selectionStart > 0) ev.preventDefault(); return; }
        if (k === 46) { if (this.value.indexOf('.') >= 0) ev.preventDefault(); return; }
        if (k < 48 || k > 57) ev.preventDefault();
    });
    $(document).on('input paste', '#karigar-jama-form .kj-numeric', function() { sanitizeNumericInput(this); });
});
</script>
<script>
(function(){
    var caratOptions = <?php echo json_encode($caratOptions); ?>;
    var caratOpts = '<option value="">Carat</option>';
    for (var carat in caratOptions) { caratOpts += '<option value="'+carat+'">'+caratOptions[carat]+'</option>'; }

    function parseNum(val) {
        var n = parseFloat(String(val).replace(/,/g, ''));
        return isNaN(n) ? 0 : n;
    }
    function getTouchByCarat(carat) {
        var touchMap = {
            '24K': '100',
            '22K': '92',
            '18K': '75',
            '14K': '58'
        };
        return touchMap[carat] || '';
    }
    function applyTouchFromCarat($block) {
        var carat = $block.find('select[name*="[carat]"]').val();
        var touch = getTouchByCarat(carat);
        $block.find('input[name*="[touch_pct]"]').val(touch);
    }
    function updateJamaTotals() {
        var totalFine = 0, totalAmt = 0;
        $('#lines-container .line-block').each(function(){
            var $block = $(this);
            var net = parseNum($block.find('input[placeholder="Net"]').val());
            var touch = parseNum($block.find('input[placeholder="Touch%"]').val());
            var wastage = parseNum($block.find('input[placeholder="Wst"]').val());
            totalFine += ((touch + wastage) / 100) * net;
            $block.find('input[name*="[stone_amount]"]').each(function(){ totalAmt += parseNum($(this).val()); });
        });
        $('#jama-total-fine-wt').text(totalFine.toFixed(3));
        $('#jama-total-amount').text(totalAmt.toFixed(2));
    }
    var lineIdx = <?php echo count($lines); ?>;
    $('#add-line-btn').on('click', function(){
        var html = '<div class="line-block panel panel-default" data-idx="'+lineIdx+'"><div class="panel-body">';
        html += '<div class="row margin-bottom-5"><div class="col-sm-1"><strong>Sr</strong></div><div class="col-sm-1"><strong>Order No</strong></div><div class="col-sm-1"><strong>Customer</strong></div><div class="col-sm-1"><strong>Item</strong></div><div class="col-sm-1"><strong>Carat</strong></div><div class="col-sm-1"><strong>Psc</strong></div><div class="col-sm-1"><strong>Gross</strong></div><div class="col-sm-1"><strong>Net</strong></div><div class="col-sm-1"><strong>Touch%</strong></div><div class="col-sm-1"><strong>Wst</strong></div><div class="col-sm-1"><strong>Remark</strong></div><div class="col-sm-1"></div></div>';
        html += '<div class="row form-group"><div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][sr_no]" class="form-control input-sm kj-numeric" placeholder="Sr" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][order_no]" class="form-control input-sm kj-numeric" placeholder="Order No" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][customer_name]" class="form-control input-sm" placeholder="Customer" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][item_name]" class="form-control input-sm" placeholder="Item" /></div>';
        html += '<div class="col-sm-1"><select name="lines['+lineIdx+'][carat]" class="form-control input-sm">'+caratOpts+'</select></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][psc]" class="form-control input-sm kj-numeric" placeholder="Psc" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][gross_wt]" class="form-control input-sm kj-numeric" placeholder="Gross" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][net_wt]" class="form-control input-sm kj-numeric" placeholder="Net" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][touch_pct]" class="form-control input-sm kj-numeric" placeholder="Touch%" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][wastage]" class="form-control input-sm kj-numeric" value="0" placeholder="Wst" /></div>';
        html += '<div class="col-sm-1"><input type="text" name="lines['+lineIdx+'][remark]" class="form-control input-sm" placeholder="Remark" /></div>';
        html += '<div class="col-sm-1"><button type="button" class="btn btn-danger btn-sm btn-remove-line">Remove</button></div></div>';
        html += '<div class="small mt-2"><div class="row margin-bottom-5"><div class="col-sm-2"><strong>Stone/Diamond/Other:</strong></div><div class="col-sm-2"><strong>Item</strong></div><div class="col-sm-2"><strong>Weight</strong></div><div class="col-sm-2"><strong>Amount</strong></div><div class="col-sm-2"><button type="button" class="btn btn-xs btn-primary btn-add-stone">+ Add stone</button></div></div>';
        html += '<div class="stone-rows" data-line-idx="'+lineIdx+'"><div class="row stone-row margin-bottom-5"><div class="col-sm-2"></div><div class="col-sm-2"><input type="text" name="lines['+lineIdx+'][stones][0][item]" class="form-control input-sm" placeholder="Item" /></div><div class="col-sm-2"><input type="text" name="lines['+lineIdx+'][stones][0][stone_wt]" class="form-control input-sm kj-numeric" placeholder="Wt" /></div><div class="col-sm-2"><input type="text" name="lines['+lineIdx+'][stones][0][stone_amount]" class="form-control input-sm kj-numeric" placeholder="Amt" /></div><div class="col-sm-2"><button type="button" class="btn btn-xs btn-danger btn-remove-stone">Remove</button></div></div></div></div></div></div></div></div></div></div></div>';
        $('#lines-container').append(html);
        lineIdx++;
        updateJamaTotals();
    });
    $(document).on('click', '.btn-remove-line', function(){ $(this).closest('.line-block').remove(); updateJamaTotals(); });
    $(document).on('click', '.btn-add-stone', function(){
        var $wrap = $(this).closest('.line-block').find('.stone-rows');
        var idx = $wrap.attr('data-line-idx');
        var stoneIdx = $wrap.find('.stone-row').length;
        var row = '<div class="row stone-row margin-bottom-5"><div class="col-sm-2"></div>';
        row += '<div class="col-sm-2"><input type="text" name="lines['+idx+'][stones]['+stoneIdx+'][item]" class="form-control input-sm" placeholder="Item" /></div>';
        row += '<div class="col-sm-2"><input type="text" name="lines['+idx+'][stones]['+stoneIdx+'][stone_wt]" class="form-control input-sm kj-numeric" placeholder="Wt" /></div>';
        row += '<div class="col-sm-2"><input type="text" name="lines['+idx+'][stones]['+stoneIdx+'][stone_amount]" class="form-control input-sm kj-numeric" placeholder="Amt" /></div>';
        row += '<div class="col-sm-2"><button type="button" class="btn btn-xs btn-danger btn-remove-stone">Remove</button></div></div>';
        $wrap.append(row);
        updateJamaTotals();
    });
    $(document).on('click', '.btn-remove-stone', function(){
        var $rows = $(this).closest('.stone-rows').find('.stone-row');
        if ($rows.length > 1) { $(this).closest('.stone-row').remove(); updateJamaTotals(); }
    });
    $('#lines-container').on('change', 'select[name*="[carat]"]', function(){
        var $block = $(this).closest('.line-block');
        applyTouchFromCarat($block);
        updateJamaTotals();
    });
    $('#lines-container').on('input change', 'input[placeholder="Net"], input[placeholder="Touch%"], input[placeholder="Wst"], input[name*="[stone_amount]"]', updateJamaTotals);
    $('#lines-container .line-block').each(function(){ applyTouchFromCarat($(this)); });
    updateJamaTotals();
})();
</script>

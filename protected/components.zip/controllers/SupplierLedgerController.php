<?php

/**
 * Supplier Voucher: transaction entry (date, supplier, items with charges).
 */
class SupplierLedgerController extends Controller
{
	public $layout = '//layouts/main';

	public function filters()
	{
		return array('accessControl', 'postOnly + delete, deleteLockedSelected, deleteAllLocked');
	}

	public function accessRules()
	{
		return array(
			array('allow', 'actions' => array('index', 'admin', 'view', 'create', 'update', 'delete', 'deleteLockedSelected', 'deleteAllLocked', 'linkIssueEntry', 'pdf', 'print'), 'users' => array('@')),
			array('deny', 'users' => array('*')),
		);
	}

	public function actionIndex()
	{
		$this->actionAdmin();
	}

	public function actionAdmin()
	{
		$model = new SupplierLedgerTxn('search');
		$model->unsetAttributes();
		if (isset($_GET['SupplierLedgerTxn']))
			$model->attributes = $_GET['SupplierLedgerTxn'];
		$this->render('admin', array('model' => $model));
	}

	public function actionView($id)
	{
		$this->render('view', array('model' => $this->loadModel($id)));
	}

	public function actionCreate()
	{
		$model = new SupplierLedgerTxn;
		$this->performAjaxValidation($model);
		if (isset($_POST['SupplierLedgerTxn'])) {
			$saveAndPrint = isset($_POST['save_print']);
			$model->attributes = $_POST['SupplierLedgerTxn'];
			if ($this->saveTxnWithItems($model, isset($_POST['items']) ? $_POST['items'] : array())) {
				Yii::app()->user->setFlash('success', 'Transaction saved.');
				if ($saveAndPrint) {
					$this->redirect(array('print', 'id' => $model->id));
				}
				$this->redirect(array('view', 'id' => $model->id));
			}
		}
		$this->render('create', array('model' => $model));
	}

	public function actionUpdate($id)
	{
		$model = $this->loadModel($id);
		if (!LedgerAccess::canEditVoucher($model, 'txn_date')) {
			Yii::app()->user->setFlash('error', 'You do not have permission to edit this voucher. Staff can edit same-day unlocked vouchers, and Head can edit until voucher is locked.');
			$this->redirect(array('view', 'id' => $model->id));
			return;
		}
		$this->performAjaxValidation($model);
		if (isset($_POST['SupplierLedgerTxn'])) {
			$saveAndPrint = isset($_POST['save_print']);
			$model->attributes = $_POST['SupplierLedgerTxn'];
			$items = isset($_POST['items']) ? $_POST['items'] : array();
			if ($this->saveTxnWithItems($model, $items)) {
				Yii::app()->user->setFlash('success', 'Transaction updated.');
				if ($saveAndPrint) {
					$this->redirect(array('print', 'id' => $model->id));
				}
				$this->redirect(array('view', 'id' => $model->id));
			}
		}
		$this->render('update', array('model' => $model));
	}

	public function actionDelete($id)
	{
		$model = $this->loadModel($id);
		if (!LedgerAccess::canDeleteVoucher($model, 'txn_date')) {
			Yii::app()->user->setFlash('error', 'You do not have permission to delete this voucher. Staff can delete same-day vouchers only, Head can delete unlocked vouchers, and locked vouchers are Admin only.');
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
			return;
		}
		$model->delete();
		Yii::app()->user->setFlash('success', 'Transaction deleted.');
		$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	public function actionDeleteLockedSelected()
	{
		if (!LedgerAccess::isAdmin()) {
			throw new CHttpException(403, 'Only Admin can delete locked vouchers.');
		}
		$ids = isset($_POST['ids']) ? $_POST['ids'] : array();
		if (!is_array($ids)) {
			$ids = array($ids);
		}
		$deletedCount = 0;
		foreach ($ids as $id) {
			$id = (int) $id;
			if ($id <= 0) continue;
			$model = SupplierLedgerTxn::model()->findByPk($id, 't.is_deleted = 0');
			if ($model && (int)$model->is_locked === 1) {
				if ($model->delete()) {
					$deletedCount++;
				}
			}
		}
		if ($deletedCount > 0) {
			Yii::app()->user->setFlash('success', $deletedCount . ' locked voucher(s) deleted successfully.');
		} else {
			Yii::app()->user->setFlash('info', 'No locked vouchers were deleted.');
		}
		$this->redirect(array('admin'));
	}

	public function actionDeleteAllLocked()
	{
		if (!LedgerAccess::isAdmin()) {
			throw new CHttpException(403, 'Only Admin can delete locked vouchers.');
		}
		$lockedRows = SupplierLedgerTxn::model()->findAll('t.is_deleted = 0 AND t.is_locked = 1');
		$deletedCount = 0;
		foreach ($lockedRows as $row) {
			if ($row->delete()) {
				$deletedCount++;
			}
		}
		Yii::app()->user->setFlash('success', $deletedCount . ' locked voucher(s) deleted successfully.');
		$this->redirect(array('admin'));
	}

	/**
	 * Create or update Issue Entry from this transaction (total_fine_wt, total_amount). Supplier voucher is inward (Baki/CR).
	 * Called automatically after save; also exposed for manual link.
	 */
	public function actionLinkIssueEntry($id)
	{
		$model = $this->loadModel($id);
		$this->ensureIssueEntry($model);
		Yii::app()->user->setFlash('success', 'Issue entry linked.');
		$this->redirect(array('view', 'id' => $model->id));
	}

	/**
	 * Ensure an issue entry exists for this supplier ledger txn (create or update).
	 */
	protected function ensureIssueEntry(SupplierLedgerTxn $model)
	{
		$totalFineWt = (float) $model->total_fine_wt;
		$totalAmount = (float) $model->total_amount;
		$prefix = DocumentNumberService::getVoucherPrefix(DocumentNumberService::DOC_SUPPLIER_LEDGER_VOUCHER);
		$voucherNo = ($model->voucher_number !== null && $model->voucher_number !== '') ? $model->voucher_number : ($prefix . $model->id);
		$drcr = IssueEntry::DRCR_CREDIT;
		if ($model->issue_entry_id) {
			$entry = IssueEntry::model()->findByPk($model->issue_entry_id);
			if ($entry) {
				$entry->issue_date = $model->txn_date;
				$entry->fine_wt = $totalFineWt;
				$entry->amount = $totalAmount;
				$entry->sr_no = $voucherNo;
				$entry->drcr = $drcr;
				$entry->remarks = NULL;
				$entry->is_voucher = 1;
				$entry->save(false);
			}
		} else {
			$entry = new IssueEntry;
			$entry->issue_date = $model->txn_date;
			$entry->sr_no = $voucherNo;
			$entry->customer_id = $model->supplier_id;
			$entry->fine_wt = $totalFineWt;
			$entry->amount = $totalAmount;
			$entry->drcr = $drcr;
			$entry->remarks = NULL;
			$entry->is_voucher = 1;
			if ($entry->save(false)) {
				$model->issue_entry_id = $entry->id;
				$model->save(false);
			}
		}
	}

	/**
	 * Open transaction PDF in browser.
	 */
	public function actionPdf($id)
	{
		$model = $this->loadModel($id);
		$filename = 'Supplier-Ledger-Txn-' . $model->id . '-' . date('Y-m-d') . '.pdf';
		PdfHelper::render('viewPdf', array('model' => $model), $filename, 'I', 'A4', array(10, 10, 12, 10, 0, 0), 'P', 'gothic', false, '', false);
	}

	public function actionPrint($id)
	{
		$model = $this->loadModel($id);
		$this->renderPartial('print', array('model' => $model), false, true);
	}

	/**
	 * Save txn header, items and charges; set total_fine_wt, total_amount.
	 */
	protected function saveTxnWithItems(SupplierLedgerTxn $model, array $itemsData)
	{
		$db = Yii::app()->db;
		$tx = $db->beginTransaction();
		$committed = false;
		try {
			$model->drcr = IssueEntry::DRCR_CREDIT;
			if (!$model->save()) {
				$tx->rollBack();
				return false;
			}
			$txnId = $model->id;
			// Remove existing items (cascade will remove charges)
			SupplierLedgerTxnItem::model()->deleteAll('txn_id = :tid', array(':tid' => $txnId));
			$totalFineWt = 0;
			$totalAmount = 0;
			$sortOrder = 0;
			$caratOptions = SupplierLedgerTxnItem::getCaratOptions();
			foreach ($itemsData as $row) {
				$itemName = $this->getTypedFieldValue($row, 'item_name', 'trimmed_string', '');
				$netWt = $this->getTypedFieldValue($row, 'net_wt', 'float', null);
				if ($itemName === '') continue;
				$ct = $this->getTypedFieldValue($row, 'ct', 'trimmed_string', '');
				if ($ct !== '' && !isset($caratOptions[$ct])) {
					$ct = '';
				}
				$item = new SupplierLedgerTxnItem;
				$item->txn_id = $txnId;
				$item->item_name = $itemName;
				$item->customer_name = $this->getTypedFieldValue($row, 'customer_name', 'trimmed_string', null);
				$item->ct = $ct !== '' ? $ct : null;
				$item->gross_wt = $this->getTypedFieldValue($row, 'gross_wt', 'float', null);
				$item->net_wt = $netWt;
				$item->touch_pct = $this->getTypedFieldValue($row, 'touch_pct', 'float', null);
				$item->wastage = $this->getTypedFieldValue($row, 'wastage', 'float', 0);
				$item->sort_order = $sortOrder++;
				$item->save(false);
				$itemTotal = 0;
				$charges = $this->getTypedFieldValue($row, 'charges', 'array', array());
				foreach ($charges as $c) {
					$chargeType = $this->getTypedFieldValue($c, 'charge_type', 'int', null);
					$chargeName = $this->getTypedFieldValue($c, 'charge_name', 'trimmed_string', null);
					$quantity = $this->getTypedFieldValue($c, 'quantity', 'float', 0);
					$rate = $this->getTypedFieldValue($c, 'rate', 'float', 0);
					if ($chargeType === null || ($chargeType == 5 && empty($chargeName) && (float) $quantity == 0)) continue;
					$ch = new SupplierLedgerTxnItemCharge;
					$ch->txn_item_id = $item->id;
					$ch->charge_type = $chargeType;
					$ch->charge_name = $chargeName;
					$ch->quantity = $quantity;
					$ch->rate = $rate;
					$ch->save(false);
					if($ch->amount && is_numeric($ch->amount))
					$itemTotal += (float) $ch->amount;
				}
				$item->item_total = $itemTotal;
				$item->save(false);
				$totalFineWt += (float) $item->fine_wt;
				$totalAmount += $itemTotal;
			}
			$model->total_fine_wt = $totalFineWt;
			$model->total_amount = $totalAmount;
			$model->save(false);
			$tx->commit();
			$committed = true;
			$this->ensureIssueEntry($model);
			return true;
		} catch (Exception $e) {
			if (!$committed)
				$tx->rollBack();
			$model->addError('txn_date', $e->getMessage());
			return false;
		}
	}

	public function loadModel($id)
	{
		$model = SupplierLedgerTxn::model()->findByPk($id, 't.is_deleted = 0');
		if ($model === null)
			throw new CHttpException(404, 'The requested page does not exist.');
		return $model;
	}

	protected function performAjaxValidation($model)
	{
		if (isset($_POST['ajax']) && $_POST['ajax'] === 'supplier-ledger-txn-form') {
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
